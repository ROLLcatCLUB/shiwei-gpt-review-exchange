from __future__ import annotations

import argparse
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import textwrap
import zipfile


TASK_ID = "XIAOJIAO_AGENT_02_TRUSTED_AGENT_CONTEXT_ENVELOPE_CONTRACT_AND_DEPENDENCY_CLOSURE"
PACKAGE_BASENAME = (
    "SHIWEI_XIAOJIAO_AGENT_02_TRUSTED_AGENT_CONTEXT_ENVELOPE_"
    "CONTRACT_AND_DEPENDENCY_CLOSURE_CUMULATIVE_REVIEW_20260811_V1"
)
STOP_POINT = (
    "HOLD_FOR_XIAOJIAO_AGENT_GPT_XIAOJIAO_AGENT_02_"
    "TRUSTED_AGENT_CONTEXT_ENVELOPE_CONTRACT_AND_DEPENDENCY_CLOSURE_CUMULATIVE_REVIEW"
)
GENERATED_AT = "2026-08-11T19:26:36+08:00"
FIXED_ZIP_TIMESTAMP = (2026, 8, 11, 0, 0, 0)
ROOT = Path(__file__).resolve().parent
ZIP_PATH = ROOT.parent / f"{PACKAGE_BASENAME}.zip"

TASK_SOURCE = (
    r"C:\Users\Administrator\.codex\attachments\dc180e4a-e227-4d2c-b4cb-ffed873f28a4\pasted-text.txt"
)
PARENT_ZIP = r"C:\Users\Administrator\Documents\Codex\2026-08-11\shiwei-xiaojiao-agent-orchestration-engineering-line-agent-00\outputs\SHIWEI_XIAOJIAO_AGENT_01_FORMAL_FOUNDATION_HOST_AND_WORKING_BASELINE_CLOSURE_CUMULATIVE_REVIEW_20260811_V1.zip"
HOST_REPO = r"D:\Documents\SmartEdu\shiwei-ai-workbench-site"
GOV_REPO = r"D:\Documents\SmartEdu\shiwei-project-governance"
E5_ROOT = r"D:\sw\shiwei-shared-identity-e5-authorization-context-01\packages\runtime-data-foundation"
E5_BINDING = r"D:\sw\shiwei-shared-identity-e5-formal-review-binding-20260810\packages\runtime-data-foundation\review-evidence\shared-identity-e5\REVIEW_BINDINGS\GPT_REVIEW_BINDING_RECORD.json"
PREP_RELEASE_BINDING = r"D:\sw\shiwei-shared-context-to-prep-formal-review-binding-20260810\packages\runtime-data-foundation\review-evidence\shared-context-to-prep\REVIEW_BINDINGS\GPT_REVIEW_BINDING_RECORD.json"
PREP_ADOPTION = r"D:\sw\prep-room-trusted-caller-academic-term-adoption-01"


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def strict_pairs(pairs: list[tuple[str, object]]) -> dict[str, object]:
    result: dict[str, object] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def write_text(name: str, content: str) -> None:
    normalized = content.replace("\r\n", "\n").replace("\r", "\n")
    with (ROOT / name).open("w", encoding="utf-8", newline="\n") as stream:
        stream.write(normalized)


def write_json(name: str, payload: object) -> None:
    write_text(name, json.dumps(payload, ensure_ascii=False, indent=2) + "\n")


def common_meta(artifact: str) -> dict[str, object]:
    return {
        "TASK_ID": TASK_ID,
        "ARTIFACT": artifact,
        "GENERATED_AT": GENERATED_AT,
        "TASK_TYPE": "READONLY_AGENT_FOUNDATION_DISCOVERY_AND_CONTRACT_AUDIT",
        "FORMAL_RUNTIME_SCHEMA_IMPLEMENTATION": "NO",
        "EVIDENCE_POLICY": "FAIL_CLOSED_EXACT_SOURCE_BINDING",
    }


def context_item(
    item_id: str,
    owner: str,
    source_system: str,
    source_path: str,
    source_authority: str,
    runtime_availability: str,
    agent_availability: str,
    client_or_server: str,
    trust_class: str,
    freshness_model: str,
    revision: str,
    lifetime: str,
    stale_risk: str,
    conflict_risk: str,
    privacy_class: str,
    allowed_usage: list[str],
    formal_effect: str,
    status: str,
) -> dict[str, object]:
    return {
        "CONTEXT_ITEM_ID": item_id,
        "SEMANTIC_OWNER": owner,
        "SOURCE_SYSTEM": source_system,
        "SOURCE_PATH_OR_CONTRACT": source_path,
        "SOURCE_AUTHORITY": source_authority,
        "CURRENT_RUNTIME_AVAILABILITY": runtime_availability,
        "CURRENT_AGENT_AVAILABILITY": agent_availability,
        "CLIENT_OR_SERVER": client_or_server,
        "TRUST_CLASS": trust_class,
        "FRESHNESS_MODEL": freshness_model,
        "REVISION_OR_VERSION_IF_AVAILABLE": revision,
        "LIFETIME": lifetime,
        "STALE_RISK": stale_risk,
        "CONFLICT_RISK": conflict_risk,
        "PRIVACY_CLASS": privacy_class,
        "ALLOWED_AGENT_USAGE": allowed_usage,
        "FORMAL_EFFECT_ELIGIBILITY": formal_effect,
        "CURRENT_STATUS": status,
    }


def build_inventory() -> list[dict[str, object]]:
    accepted_not_adopted = "REAL_ACCEPTED_BUT_NOT_AGENT_ADOPTED"
    fixture = "FIXTURE"
    hint = "CLIENT_VIEW_HINT"
    page = "PAGE_LOCAL_STATE"
    missing = "MISSING"
    shared_contract = E5_ROOT + r"\contracts\shared-identity\README.md"
    e5_source = E5_ROOT + r"\src\shared-identity"
    academic_term_contract = E5_ROOT + r"\contracts\academic-term\README.md"
    page_source = HOST_REPO + r"\app\shell-v1\page.tsx"
    classroom_contract = HOST_REPO + r"\domain\classroom\contracts.ts"
    shell_contract = HOST_REPO + r"\domain\contracts.ts"
    items = [
        context_item(
            "VerifiedExternalAuthenticationProof",
            "SHARED_IDENTITY_E0",
            "Clerk verification boundary in accepted runtime-data-foundation",
            shared_contract,
            "Accepted E0 server verification semantics; proof is authentication evidence only",
            "AVAILABLE_IN_ACCEPTED_UPSTREAM_SERVER_IMPLEMENTATION",
            "NOT_WIRED_TO_AGENT_HOST_REQUEST_PATH",
            "SERVER_ONLY",
            "DERIVED_TRUSTED_WHEN_ISSUED_BY_E0",
            "REVERIFY_PER_REQUEST_OR_TRUSTED_SESSION_BOUNDARY",
            "proof contract v1; token/session freshness is provider-derived",
            "REQUEST",
            "CRITICAL",
            "PROVIDER_SESSION_OR_HOST_CLOCK_DIVERGENCE",
            "SECURITY_SENSITIVE",
            ["bootstrap trusted identity chain", "never project raw token or proof to model"],
            "ELIGIBLE_ONLY_INSIDE_ACCEPTED_SERVER_CHAIN",
            accepted_not_adopted,
        ),
        context_item(
            "Principal",
            "SHARED_IDENTITY_E1",
            "runtime-data-foundation stable Principal binding",
            e5_source + r"\e1",
            "Accepted opaque UUID derived server-side from authorityId, issuer and externalSubject",
            "AVAILABLE_IN_ACCEPTED_UPSTREAM_SERVER_IMPLEMENTATION",
            "NOT_WIRED_TO_AGENT_HOST",
            "SERVER_ONLY",
            "REAL_ACCEPTED_SOURCE_UPSTREAM",
            "RESOLVE_AND_VALIDATE_PER_TRUSTED_REQUEST",
            "Principal stable ID plus source revision when returned by trusted source",
            "REQUEST_REFERENCE",
            "CRITICAL",
            "EXTERNAL_SUBJECT_OR_BINDING_MISMATCH",
            "PERSONAL_IDENTIFIER_MINIMIZED",
            ["request ownership", "authorization routing", "audit correlation via opaque reference"],
            "ELIGIBLE_AFTER_AGENT_SERVER_ADOPTION_AND_E5_VALIDATION",
            accepted_not_adopted,
        ),
        context_item(
            "Organization",
            "SHARED_IDENTITY_E2",
            "runtime-data-foundation stable Organization",
            e5_source + r"\e2",
            "Accepted stable organization record; not a browser assertion",
            "AVAILABLE_IN_ACCEPTED_UPSTREAM_SERVER_IMPLEMENTATION",
            "NOT_WIRED_TO_AGENT_HOST",
            "SERVER_ONLY",
            "REAL_ACCEPTED_SOURCE_UPSTREAM",
            "REVALIDATE_ACTIVE_STATUS_AND_REVISION",
            "Organization revision",
            "REQUEST_REFERENCE",
            "CRITICAL",
            "CLIENT_REQUESTED_ORG_OR_STALE_RECORD_CONFLICT",
            "ORGANIZATION_INTERNAL_MINIMIZED",
            ["active scope reference", "domain routing", "authorization checks"],
            "ELIGIBLE_AFTER_AGENT_SERVER_ADOPTION",
            accepted_not_adopted,
        ),
        context_item(
            "Membership",
            "SHARED_IDENTITY_E3",
            "runtime-data-foundation OrganizationMembership relation episode",
            e5_source + r"\e3",
            "Accepted server-side relationship; effective only when principal, organization and membership are active",
            "AVAILABLE_IN_ACCEPTED_UPSTREAM_SERVER_IMPLEMENTATION",
            "NOT_WIRED_TO_AGENT_HOST",
            "SERVER_ONLY",
            "REAL_ACCEPTED_SOURCE_UPSTREAM",
            "REVALIDATE_STATUS_AND_REVISION_PER_AUTHORITY_BOUNDARY",
            "Membership revision",
            "REQUEST_REFERENCE",
            "CRITICAL",
            "REVOKED_OR_CHANGED_MEMBERSHIP",
            "SECURITY_SENSITIVE_RELATIONSHIP",
            ["active organization resolution", "authorization provenance"],
            "ELIGIBLE_AFTER_CURRENT E3 VALIDATION",
            accepted_not_adopted,
        ),
        context_item(
            "ActiveOrganizationContext",
            "SHARED_IDENTITY_E4",
            "runtime-data-foundation request-scoped E4 resolution",
            e5_source + r"\e4",
            "Accepted server resolver; client may supply only optional requested organization candidate",
            "AVAILABLE_IN_ACCEPTED_UPSTREAM_SERVER_IMPLEMENTATION",
            "NOT_WIRED_TO_AGENT_HOST",
            "SERVER_ONLY_WITH_OPTIONAL_UNTRUSTED_CLIENT_CANDIDATE",
            "DERIVED_TRUSTED_WHEN_RESOLVED_BY_E4",
            "RESOLVE_PER_REQUEST_AND_REVALIDATE_ON_PROCESS_BFF_OR_SESSION_CROSSING",
            "Principal, organization and membership revisions",
            "REQUEST",
            "CRITICAL",
            "MULTIPLE_MEMBERSHIPS_OR_CLIENT_SERVER_MISMATCH",
            "SECURITY_SENSITIVE_MINIMIZED",
            ["bind request to one active organization", "issue E5 context"],
            "ELIGIBLE_ONLY_WHEN_UNAMBIGUOUS_AND_CURRENT",
            accepted_not_adopted,
        ),
        context_item(
            "AuthorizationContext",
            "SHARED_IDENTITY_E5",
            "runtime-data-foundation request-scoped E5 context",
            e5_source + r"\e5",
            "Accepted server-issued context with in-process provenance; structural copy is not authority",
            "AVAILABLE_IN_ACCEPTED_UPSTREAM_SERVER_IMPLEMENTATION",
            "NO_AGENT_CONSUMER_CHANNEL_OR_REQUEST_ADOPTION",
            "TRUSTED_SERVER_PROCESS_ONLY",
            "DERIVED_TRUSTED_OPAQUE_HANDLE",
            "ISSUE_AND_VALIDATE_PER_REQUEST; NEVER SERIALIZE_OR_CACHE",
            "Principal/org/membership/grant/catalog/policy revisions and issuedAt",
            "REQUEST_IN_PROCESS",
            "CRITICAL",
            "PROVENANCE_LOSS_OR_REVISION_DRIFT",
            "HIGH_SECURITY_SENSITIVE",
            ["authorization gate", "capability check at E5 boundary", "never copy into prompt"],
            "ELIGIBLE_ONLY_AS_LIVE_E5_ISSUED_HANDLE",
            accepted_not_adopted,
        ),
        context_item(
            "EffectiveCapabilities",
            "SHARED_IDENTITY_E5",
            "E5 capability grants and catalog",
            e5_source + r"\e5",
            "Accepted exact capability semantics; server grants, not roles or client claims",
            "AVAILABLE_IN_ACCEPTED_UPSTREAM_SERVER_IMPLEMENTATION",
            "NO_AGENT_CAPABILITY_CATALOG_OR_GRANTS_ADOPTED",
            "SERVER_ONLY",
            "DERIVED_TRUSTED_INSIDE_AUTHORIZATION_CONTEXT",
            "VALIDATE_EXACT_CAPABILITY_AND_ALL_SOURCE_REVISIONS_PER_USE",
            "Grant, catalog and policy revisions",
            "REQUEST",
            "CRITICAL",
            "GRANT_REVOCATION_OR_CATALOG_DRIFT",
            "HIGH_SECURITY_SENSITIVE",
            ["server-side capability decision only", "route to allowed domain adapter"],
            "ELIGIBLE_ONLY_THROUGH_E5_API; NEVER_BROWSER_DECLARED",
            accepted_not_adopted,
        ),
        context_item(
            "AcademicTerm",
            "PREP_SEMANTICS_AND_CRDF_PERSISTENCE",
            "accepted AcademicTerm read contract in runtime-data-foundation",
            academic_term_contract,
            "Accepted stable term records and revisions; discovery order is not WorkingTerm selection",
            "AVAILABLE_UPSTREAM_AND_PREP_SPECIFIC_RELEASE_ACCEPTED",
            "NOT_ADOPTED_BY_AGENT; PREP_EXPORT_IS_NOT_AGENT_AUTHORITY",
            "SERVER_RESOLVED",
            "REAL_ACCEPTED_SOURCE_UPSTREAM",
            "REVISION_CHECK_ON_RESOLUTION_AND_BEFORE_DOMAIN_USE",
            "AcademicTerm revision",
            "REQUEST_REFERENCE_WITH_ON_DEMAND_REFRESH",
            "HIGH",
            "TERM_REVISION_OR_WORKING_SELECTION_CONFLATION",
            "SCHOOL_OPERATIONAL_MINIMIZED",
            ["on-demand term reference after Agent-specific accepted contract", "never infer WorkingTerm from discovery order"],
            "NOT_CURRENTLY_AGENT_ELIGIBLE",
            accepted_not_adopted,
        ),
        context_item(
            "WorkingTermSelection",
            "PREP",
            "PREP adoption candidate",
            PREP_ADOPTION + r"\app\shell-v1\prep",
            "Candidate browser preference bound to principal, organization and term then server-revalidated; no formal acceptance binding found",
            "CANDIDATE_ONLY_IN_PREP_WORKTREE",
            "NOT_AVAILABLE_TO_AGENT",
            "CLIENT_PREFERENCE_PLUS_SERVER_REVALIDATION",
            "DOMAIN_CANDIDATE",
            "SESSION_PREFERENCE; REVALIDATE_BINDINGS_AND_TERM_REVISION",
            "Candidate term reference and bindings",
            "BROWSER_SESSION",
            "HIGH",
            "STALE_PREFERENCE_OR_DIFFERENT_PRINCIPAL_OR_ORG",
            "SCHOOL_OPERATIONAL_MINIMIZED",
            ["none as trusted Agent fact", "may motivate PREP owner requirement"],
            "NO",
            "DOMAIN_CANDIDATE",
        ),
        context_item(
            "CurrentRoom",
            "AGENT_ORCHESTRATION_VIEW_COMPOSITION",
            "shell route and visible surface",
            page_source,
            "Browser view state only; route is not domain or authorization authority",
            "VISIBLE_IN_CURRENT_HOST_UI",
            "AVAILABLE_ONLY_AS_UNTRUSTED_VIEW_HINT",
            "CLIENT",
            "CLIENT_VIEW_HINT",
            "CURRENT_NAVIGATION_EVENT_OR_PAGE_LIFETIME",
            "Route/version not canonical",
            "PAGE_OR_NAVIGATION",
            "MEDIUM",
            "ROUTE_DOMAIN_AUTHORITY_CONFLATION",
            "LOW_UNLESS_ROUTE_CONTAINS_IDENTIFIERS",
            ["explain visible surface", "safe navigation suggestion", "choose which server resolver to ask"],
            "NO",
            hint,
        ),
        context_item(
            "CurrentPREPContext",
            "PREP_FOR_DOMAIN; AGENT_FOR_VIEW_COMPOSITION",
            "shell route and PREP client selection",
            page_source,
            "Client view hint; no accepted Agent-facing PREP current-context contract",
            "VISIBLE_AS_UI_STATE",
            "VIEW_HINT_ONLY",
            "CLIENT",
            "CLIENT_VIEW_HINT",
            "PAGE_LIFETIME",
            "None",
            "PAGE",
            "HIGH",
            "VISIBLE_PREP_SURFACE_WITHOUT_CANONICAL_PREPARATION",
            "TEACHER_WORK_CONTEXT_MINIMIZED",
            ["route explanation", "request PREP server resolution"],
            "NO",
            hint,
        ),
        context_item(
            "CurrentPreparationLesson",
            "PREP",
            "academicWorkspaceFixture and lesson query parameter",
            page_source,
            "Fixture plus client parameter; no accepted canonical current Preparation supplied to Agent",
            "FIXTURE_VISIBLE",
            "NOT_TRUSTED",
            "CLIENT_AND_FIXTURE",
            "NON_AUTHORITATIVE",
            "PAGE_LIFETIME_ONLY",
            "Fixture identifier only",
            "PAGE",
            "CRITICAL_IF_MISUSED",
            "FIXTURE_REALITY_CONFLICT",
            "TEACHER_WORK_CONTENT",
            ["demo rendering only", "must be labeled non-authoritative"],
            "NO",
            fixture,
        ),
        context_item(
            "CurrentClassroomContext",
            "CLASSROOM_FOR_DOMAIN; AGENT_FOR_VIEW_COMPOSITION",
            "room=classroom route plus classroom fixtures",
            page_source,
            "Current route is hint; classroom object is fixtureOnly",
            "VISIBLE_IN_UI",
            "VIEW_HINT_SEPARABLE_FROM_FIXTURE_PAYLOAD",
            "CLIENT_AND_FIXTURE",
            "NON_AUTHORITATIVE",
            "PAGE_LIFETIME",
            "Fixture/version labels only",
            "PAGE",
            "CRITICAL_IF_MISUSED",
            "ROUTE_AND_FIXTURE_CONFLATION",
            "CLASSROOM_OPERATIONAL_SENSITIVE",
            ["use route portion only as view hint", "exclude fixture data from trusted envelope"],
            "NO",
            fixture,
        ),
        context_item(
            "CurrentClassroomSession",
            "CLASSROOM",
            "classroom contract fixtureOnly preview",
            classroom_contract,
            "Explicit fixtureOnly, non-persisted session preview",
            "FIXTURE_ONLY",
            "NOT_TRUSTED",
            "FIXTURE",
            "NON_AUTHORITATIVE",
            "DEMO_SESSION_ONLY",
            "Fixture revision only",
            "PAGE_OR_DEMO_SESSION",
            "CRITICAL_IF_MISUSED",
            "FIXTURE_REALITY_CONFLICT",
            "HIGH_CLASSROOM_AND_STUDENT_SENSITIVITY",
            ["demo presentation only"],
            "NO",
            fixture,
        ),
        context_item(
            "CurrentReviewContext",
            "REVIEW_FOR_DOMAIN; AGENT_FOR_VIEW_COMPOSITION",
            "shell route/view state",
            page_source,
            "Visible Review surface only; no accepted Agent-facing Review current-context contract",
            "VISIBLE_AS_UI_STATE",
            "VIEW_HINT_ONLY",
            "CLIENT",
            "CLIENT_VIEW_HINT",
            "PAGE_LIFETIME",
            "None",
            "PAGE",
            "HIGH",
            "VISIBLE_REVIEW_SURFACE_WITHOUT_CANONICAL_ITEM",
            "REVIEW_CONTENT_SENSITIVE",
            ["route explanation", "request Review-owned resolver"],
            "NO",
            hint,
        ),
        context_item(
            "CurrentReviewItem",
            "REVIEW",
            "current host fixture/local UI state",
            page_source,
            "No accepted stable Review item reference exposed to Agent",
            "FIXTURE_OR_ABSENT",
            "NOT_TRUSTED",
            "CLIENT_OR_FIXTURE",
            "NON_AUTHORITATIVE",
            "PAGE_LIFETIME",
            "None",
            "PAGE",
            "CRITICAL_IF_MISUSED",
            "FIXTURE_REALITY_CONFLICT",
            "HIGH_REVIEW_SENSITIVITY",
            ["none beyond clearly labeled demo explanation"],
            "NO",
            fixture,
        ),
        context_item(
            "ClassInstance",
            "SCHOOL_COMMUNITY_OR_CLASSROOM_AS_FORMALLY_DECIDED",
            "academicWorkspaceFixture",
            shell_contract,
            "Current host value is fixture; accepted canonical owner-facing Agent contract not found",
            "FIXTURE_VISIBLE",
            "NOT_TRUSTED",
            "FIXTURE",
            "NON_AUTHORITATIVE",
            "NONE_FOR_REALITY",
            "Fixture only",
            "DEMO",
            "CRITICAL_IF_MISUSED",
            "FIXTURE_REALITY_CONFLICT",
            "STUDENT_GROUP_SENSITIVE",
            ["demo only"],
            "NO",
            fixture,
        ),
        context_item(
            "StudentLearner",
            "SCHOOL_COMMUNITY_AND_APPLICABLE_DOMAIN_OWNER",
            "classroom fixture data",
            classroom_contract,
            "Fixture only; no accepted Agent-facing learner reference contract",
            "FIXTURE_VISIBLE",
            "NOT_TRUSTED_AND_PROHIBITED_BY_DEFAULT",
            "FIXTURE",
            "NON_AUTHORITATIVE",
            "NONE_FOR_REALITY",
            "Fixture only",
            "DEMO",
            "CRITICAL",
            "PII_OR_FIXTURE_REALITY_CONFLICT",
            "HIGHEST_STUDENT_PRIVATE_DATA",
            ["exclude by default", "future on-demand minimum authorized reference or aggregate only"],
            "NO",
            fixture,
        ),
        context_item(
            "SubjectDefinition",
            "SCHOOL_COMMUNITY_OR_CURRICULUM_OWNER",
            "academicWorkspaceFixture",
            shell_contract,
            "Fixture; accepted Agent-facing owner contract not found",
            "FIXTURE_VISIBLE",
            "NOT_TRUSTED",
            "FIXTURE",
            "NON_AUTHORITATIVE",
            "NONE_FOR_REALITY",
            "Fixture only",
            "DEMO",
            "HIGH",
            "FIXTURE_REALITY_CONFLICT",
            "SCHOOL_OPERATIONAL",
            ["demo only"],
            "NO",
            fixture,
        ),
        context_item(
            "TeachingAssignment",
            "PREP_AND_SCHOOL_COMMUNITY_AS_FORMALLY_DECIDED",
            "academicWorkspaceFixture and PREP candidate",
            shell_contract,
            "Current host fixture; PREP candidate explicitly retains controlled fixtures",
            "FIXTURE_VISIBLE",
            "NOT_TRUSTED",
            "FIXTURE",
            "NON_AUTHORITATIVE",
            "NONE_FOR_REALITY",
            "Fixture only",
            "DEMO",
            "CRITICAL_IF_MISUSED",
            "FIXTURE_REALITY_CONFLICT",
            "TEACHER_AND_CLASS_OPERATIONAL",
            ["demo only", "future owner-resolved reference"],
            "NO",
            fixture,
        ),
        context_item(
            "CurrentRoute",
            "AGENT_ORCHESTRATION_VIEW_COMPOSITION",
            "Next.js URL and shell client state",
            page_source,
            "Browser navigation state",
            "AVAILABLE",
            "AVAILABLE_AS_VIEW_HINT",
            "CLIENT",
            "CLIENT_VIEW_HINT",
            "NAVIGATION_EVENT",
            "Route string",
            "PAGE",
            "MEDIUM",
            "ROUTE_STALE_AFTER_NAVIGATION",
            "LOW_WITH_IDENTIFIER_MINIMIZATION",
            ["safe navigation", "visible-surface explanation", "resolver selection"],
            "NO",
            hint,
        ),
        context_item(
            "CurrentSelectedObject",
            "AGENT_ORCHESTRATION_VIEW_COMPOSITION",
            "shell page-local React state",
            page_source,
            "Client selection only until owner source re-resolves a stable reference",
            "AVAILABLE_AS_PAGE_LOCAL_STATE",
            "PAGE_LOCAL_ONLY",
            "CLIENT",
            "PAGE_LOCAL_STATE",
            "PAGE_LIFETIME",
            "No canonical revision",
            "PAGE",
            "HIGH",
            "SELECTION_WITHOUT_DOMAIN_SOURCE",
            "DEPENDS_ON_SELECTED_OBJECT",
            ["view hint", "server-revalidatable reference candidate if structurally safe"],
            "NO",
            page,
        ),
        context_item(
            "AgentDockLocalState",
            "AGENT_UI_ONLY",
            "AgentDock React useState",
            page_source + "::AgentDock",
            "UI-only transient state; context prop is unused and buttons have no trusted handlers",
            "AVAILABLE_IN_CURRENT_HEAD_UI",
            "UI_ONLY_NOT_CONTEXT_AUTHORITY",
            "CLIENT",
            "PAGE_LOCAL_STATE",
            "COMPONENT_LIFETIME",
            "None",
            "COMPONENT",
            "HIGH_IF_TREATED_AS_CONTEXT",
            "UI_STATE_DOMAIN_CONFLATION",
            "POTENTIALLY_USER_TEXT_SENSITIVE",
            ["rendering only", "must not authorize or establish domain fact"],
            "NO",
            page,
        ),
        context_item(
            "AgentRequestSessionCorrelation",
            "FUTURE_AGENT_SERVER_BOUNDARY",
            "No accepted Agent request ingress or correlation contract found",
            "NOT_FOUND_IN_AUTHORIZED_WORKING_START_OR_CURRENT_HOST",
            "None",
            "MISSING",
            "MISSING",
            "UNKNOWN",
            "UNKNOWN",
            "MUST_BE_REQUEST_SCOPED_AND_NON_SECRET",
            "None",
            "REQUEST",
            "CRITICAL_FOR_AUDITABILITY",
            "DUPLICATE_OR_CROSS_SESSION_MISBINDING",
            "PSEUDONYMOUS_OPERATIONAL",
            ["future audit correlation only; never substitute for identity"],
            "NO",
            missing,
        ),
    ]
    if len(items) != 24:
        raise AssertionError(f"expected 24 context items, got {len(items)}")
    return items


def build_artifacts() -> None:
    inventory = build_inventory()
    status_counts: dict[str, int] = {}
    for item in inventory:
        status = str(item["CURRENT_STATUS"])
        status_counts[status] = status_counts.get(status, 0) + 1

    parent = {
        **common_meta("PARENT_AUTHORITY_AND_BASELINE_RECOVERY"),
        "TASK_AUTHORITY": {
            "PATH": TASK_SOURCE,
            "BYTES": 37113,
            "SHA256": "D5850CAD1AC9CB3C393F0E3A49A8F02143987709E1CEDC100791EA18CDB8A8B3",
            "LINES": 2259,
            "FULL_READ": "PASS",
        },
        "PARENT_TASK": {
            "TASK_ID": "XIAOJIAO_AGENT_01_FORMAL_FOUNDATION_HOST_AND_WORKING_BASELINE_CLOSURE",
            "REVIEW_RESULT": "PASS_AND_CLOSE",
            "PACKAGE": PARENT_ZIP,
            "PACKAGE_BYTES": 46629,
            "PACKAGE_SHA256": "DD1C4EC5AEB30CE8AF9D1E69782CAC73B0FBBB1D44181AE713F62948B483C36C",
            "PACKAGE_ENTRY_COUNT": 20,
        },
        "FORMAL_HOST_DECISION": {
            "FORMAL_AGENT_FOUNDATION_HOST_REPOSITORY": HOST_REPO,
            "AGENT_MODULE_OWNERSHIP": "SAME_LOGICAL_REPOSITORY_BOUNDED_OWNED_MODULE",
            "EXACT_AGENT_MODULE_SUBPATH": "NOT_AUTHORIZED_OR_SELECTED",
            "SERVER_BOUNDARY": "SAME_LOGICAL_REPOSITORY_TRUSTED_SERVER_ONLY",
            "EXACT_SERVER_SUBPATH": "NOT_AUTHORIZED_OR_SELECTED",
            "UI_SURFACE": "app/shell-v1/page.tsx::AgentDock",
            "UI_SURFACE_AUTHORITY": "UI_ONLY",
        },
        "AUTHORIZED_WORKING_START": {
            "TAG_REF": "refs/tags/classroom-semester-workset-m2-accepted-20260718",
            "TAG_OBJECT": "515fb80af564b72245a2ec272482873a814336e7",
            "COMMIT": "c875cde9ab63bca2b9c06ec17832393a67d0e617",
            "TREE": "a1ba3d4d715539987db8cd8b03ce1020eddddd74",
            "ACCEPTED_SCOPE": "app/shell-v1/classroom",
            "SEMANTIC": "AUTHORIZED_WORKING_START_NOT_ACCEPTED_AGENT_IMPLEMENTATION_BASELINE",
        },
        "CURRENT_HOST_HEAD": {
            "BRANCH": "codex/prep-room-limited-governance-readonly-v0-1",
            "COMMIT": "4f853665a4e23f03a68f9df72d77e8131a197b84",
            "TREE": "8d6d7f36c416dd7cceebbba146e458111b6542b1",
            "WORKTREE_STATUS": "CLEAN_AT_AUDIT",
            "SEMANTIC": "CURRENT_HEAD_FACT_NOT_ACCEPTED_WORKING_BASELINE",
            "PROJECT_STATE_WARNING": "G6-era current head is DO_NOT_MERGE",
        },
        "WORKING_START_BLOBS": {
            "app/shell-v1/page.tsx": "2ac546f6fb3582e8b3db6b6f104765fbc84fce83",
            "domain/contracts.ts": "15f172f520b1881e713d4a727140caf3d20c4b36",
            "domain/classroom/contracts.ts": "1fa63cc58cdbcd29c7b3e1dada813256895358c2",
            "lib/bff.ts": "52fb4984d2b02fba79f9ec9fa4c6c860f6e9a2f2",
            "package.json": "92554014d75bdbeb29337e4898ea8007e0f7754b",
        },
        "BASELINE_FINDINGS": [
            "No Agent implementation baseline is accepted.",
            "AgentDock is UI-only and does not consume trusted context.",
            "No E0/E1/E4/E5 or runtime-data-foundation integration was found at working start or current host head.",
            "Current host route, fixtures and page-local state cannot be projected backward into the accepted working start.",
        ],
        "MUTATION_BOUNDARY": {
            "SOURCE_CODE_CHANGE_COUNT": 0,
            "GIT_MUTATION_COUNT": 0,
            "NEW_BRANCH_COUNT": 0,
            "NEW_WORKTREE_COUNT": 0,
            "AGENT_IMPLEMENTATION_CHANGE_COUNT": 0,
        },
    }

    inventory_artifact = {
        **common_meta("CONTEXT_ITEM_INVENTORY"),
        "ENUMERATION": [
            "REAL_ACCEPTED_SOURCE",
            "REAL_ACCEPTED_BUT_NOT_AGENT_ADOPTED",
            "REAL_BUT_AUTHORITY_NOT_PROVEN",
            "DOMAIN_CANDIDATE",
            "DERIVED_TRUSTED",
            "CLIENT_VIEW_HINT",
            "PAGE_LOCAL_STATE",
            "FIXTURE",
            "PROMPT_TEXT_ONLY",
            "LEGACY_ONLY",
            "STALE",
            "CONFLICTING",
            "MISSING",
            "UNKNOWN",
        ],
        "COUNTING_RULE": "REAL_ACCEPTED_SOURCE means both formally accepted and actually adopted by the current Agent request path.",
        "CONTEXT_ITEM_COUNT": len(inventory),
        "REAL_ACCEPTED_SOURCE_COUNT": status_counts.get("REAL_ACCEPTED_SOURCE", 0),
        "REAL_ACCEPTED_BUT_NOT_AGENT_ADOPTED_COUNT": status_counts.get("REAL_ACCEPTED_BUT_NOT_AGENT_ADOPTED", 0),
        "CLIENT_VIEW_HINT_COUNT": status_counts.get("CLIENT_VIEW_HINT", 0),
        "FIXTURE_COUNT": status_counts.get("FIXTURE", 0),
        "MISSING_OR_UNKNOWN_COUNT": status_counts.get("MISSING", 0) + status_counts.get("UNKNOWN", 0),
        "OTHER_STATUS_COUNTS": {
            "DOMAIN_CANDIDATE": status_counts.get("DOMAIN_CANDIDATE", 0),
            "PAGE_LOCAL_STATE": status_counts.get("PAGE_LOCAL_STATE", 0),
        },
        "ITEMS": inventory,
    }

    source_map = {
        **common_meta("CONTEXT_SOURCE_AND_AUTHORITY_MAP"),
        "LAYER_RULE": "Security/authority, domain work and interaction/view context remain separately typed and separately resolved.",
        "LAYERS": [
            {
                "LAYER": "SECURITY_AND_AUTHORITY_CONTEXT",
                "SEMANTIC_OWNER": "SHARED_IDENTITY_E0_TO_E5",
                "SOURCE_AUTHORITY": "ACCEPTED_SERVER_SIDE_E0_E1_E2_E3_E4_E5_CHAIN",
                "CLIENT_ROLE": "OPTIONAL_UNTRUSTED_ORGANIZATION_CANDIDATE_ONLY",
                "AGENT_CURRENT_STATUS": "UPSTREAM_ACCEPTED_NOT_AGENT_ADOPTED",
                "ITEMS": ["VerifiedExternalAuthenticationProof", "Principal", "Organization", "Membership", "ActiveOrganizationContext", "AuthorizationContext", "EffectiveCapabilities"],
            },
            {
                "LAYER": "DOMAIN_WORK_CONTEXT",
                "SEMANTIC_OWNER": "EACH_DOMAIN_OWNER",
                "SOURCE_AUTHORITY": "ACCEPTED_OWNER_CONTRACT_AND_REVISIONED_SOURCE_REQUIRED",
                "CLIENT_ROLE": "REFERENCE_OR_SELECTION_CANDIDATE_ONLY",
                "AGENT_CURRENT_STATUS": "ACADEMIC_TERM_ACCEPTED_UPSTREAM; OTHER_ITEMS_CANDIDATE_FIXTURE_OR_MISSING",
                "ITEMS": ["AcademicTerm", "WorkingTermSelection", "CurrentPreparationLesson", "CurrentClassroomSession", "CurrentReviewItem", "ClassInstance", "StudentLearner", "SubjectDefinition", "TeachingAssignment"],
            },
            {
                "LAYER": "INTERACTION_AND_VIEW_CONTEXT",
                "SEMANTIC_OWNER": "AGENT_ORCHESTRATION_CONTEXT_COMPOSITION_FOR_VIEW_ONLY",
                "SOURCE_AUTHORITY": "BROWSER_VIEW_STATE_WITH_NO_DOMAIN_OR_AUTHORIZATION_AUTHORITY",
                "CLIENT_ROLE": "MAY_SUGGEST_CONTEXT",
                "AGENT_CURRENT_STATUS": "AVAILABLE_ONLY_AS_HINT_OR_PAGE_LOCAL_STATE",
                "ITEMS": ["CurrentRoom", "CurrentPREPContext", "CurrentClassroomContext", "CurrentReviewContext", "CurrentRoute", "CurrentSelectedObject", "AgentDockLocalState"],
            },
        ],
        "OWNER_LOCKS": {
            "PREP": "OWNS_PREP_DOMAIN_SEMANTICS_AND_EFFECTS",
            "CLASSROOM": "OWNS_CLASSROOM_DOMAIN_SEMANTICS_AND_EFFECTS",
            "REVIEW": "OWNS_REVIEW_DOMAIN_SEMANTICS_AND_EFFECTS",
            "SCHOOL_COMMUNITY": "OWNS_SHARED_SCHOOL_COMMUNITY_FACTS",
            "SHARED_IDENTITY_E5": "OWNS_IDENTITY_AND_AUTHORIZATION_SEMANTICS",
            "CRDF": "OWNS_PERSISTENCE_MECHANICS",
            "AGENT_LINE": "OWNS_ORCHESTRATION_CONTEXT_COMPOSITION_ONLY",
        },
        "FORBIDDEN_AGENT_CANONICAL_OBJECTS": [
            "NEW_AGENT_CANONICAL_LESSON",
            "NEW_AGENT_CANONICAL_CLASS",
            "NEW_AGENT_CANONICAL_STUDENT",
            "NEW_AGENT_CANONICAL_SESSION",
            "NEW_AGENT_CANONICAL_REVIEW_ITEM",
        ],
        "TRUTH_PRECEDENCE": [
            "accepted server security authority",
            "accepted revisioned domain owner fact",
            "server-revalidated client reference",
            "client view hint",
            "page-local state",
            "fixture or legacy evidence",
        ],
    }

    security = {
        **common_meta("SECURITY_IDENTITY_E5_DEPENDENCY_AUDIT"),
        "E5_ACCEPTED_BINDING": {
            "PATH": E5_BINDING,
            "BYTES": 6583,
            "SHA256": "65A09ACB0192B0C348EB763AE3BE801BF874AD3C48D2C8E9069FEA1A3B0159B6",
            "RESULT": "PASS_AND_CLOSE_E5",
            "IMPLEMENTATION_COMMIT": "b6bd78d96bfdec514cee3ba052b11177bc08ade6",
            "IMPLEMENTATION_TREE": "7d7bd1eee34d4d200ff7650903bff37eeefae0b7",
            "IMPLEMENTATION_WORKTREE_AT_AUDIT": "CLEAN",
        },
        "ACCEPTED_CHAIN": [
            "E0 verifies external Clerk authentication proof on the server; proof is not Principal or authorization.",
            "E1 resolves stable opaque Principal from authorityId, issuer and externalSubject.",
            "E2 supplies stable Organization.",
            "E3 supplies active Membership relation episode.",
            "E4 resolves one request-scoped ActiveOrganizationContext and revalidates at boundaries.",
            "E5 issues and validates request-scoped AuthorizationContext with exact persisted grants and revisions.",
        ],
        "MANDATORY_QUESTIONS": [
            {
                "QUESTION": "Can the current server recover Principal from a trusted session/auth source?",
                "ANSWER": "Accepted upstream E0-to-E1 code can do so, but the Agent host has no accepted request ingress wired to that chain. Therefore current Agent cannot.",
                "STATUS": "PARTIAL_UPSTREAM_ONLY",
            },
            {
                "QUESTION": "Who determines Active Organization?",
                "ANSWER": "Accepted E4 server resolution from verified Principal and current active Memberships. One effective membership may auto-select; multiple memberships require explicit client candidate followed by server validation.",
                "STATUS": "ACCEPTED_SEMANTICS_NOT_AGENT_ADOPTED",
            },
            {
                "QUESTION": "Can the client declare organizationId?",
                "ANSWER": "No. It may suggest an optional requested organization candidate only; server truth wins or resolution fails closed.",
                "STATUS": "NO",
            },
            {
                "QUESTION": "How is AuthorizationContext established?",
                "ANSWER": "E5 validates E4 context and current principal/org/membership plus exact persisted grants, catalog and policy revisions, then issues a live request-scoped in-process object with WeakSet provenance.",
                "STATUS": "ACCEPTED_UPSTREAM",
            },
            {
                "QUESTION": "Are capabilities server-authoritative?",
                "ANSWER": "Yes. Exact capabilities derive from persisted grants and the E5 catalog. Browser capability or role claims are forbidden authority inputs.",
                "STATUS": "YES_UPSTREAM",
            },
            {
                "QUESTION": "What E5 ability can an Agent trusted server boundary reuse?",
                "ANSWER": "It may reuse accepted E0-E5 semantics and in-process validation APIs after a formally accepted Agent consumer channel exists. It must not serialize AuthorizationContext or generalize the PREP-specific public export.",
                "STATUS": "REUSE_SEMANTICS_AVAILABLE_CONSUMER_CHANNEL_MISSING",
            },
            {
                "QUESTION": "What Agent E2E adoption is missing?",
                "ANSWER": "No Agent auth/session ingress, Principal resolver call, E4 active-organization resolution, E5 issue/validate call, Agent capability catalog/grant, stable package export, or end-to-end tests are present in the host.",
                "STATUS": "MISSING",
            },
            {
                "QUESTION": "Does Agent need new authorization semantics?",
                "ANSWER": "No. A new Agent authorization model is forbidden; future adoption must use an Agent server adapter over accepted E5 semantics.",
                "STATUS": "NO_NEW_SEMANTICS",
            },
        ],
        "PROVENANCE_LOCK": "AuthorizationContext is trusted only as the live object issued by accepted E5 in the same trusted process. Frozen JSON, structural copies, client payloads and cache entries are not provenance.",
        "CROSS_BOUNDARY_RULE": "Crossing HTTP, BFF, session or process boundaries requires re-resolution and re-issuance; the AuthorizationContext object itself never crosses.",
        "CURRENT_PACKAGE_CONSUMER_FACT": {
            "PACKAGE": "@shiwei/runtime-data-foundation",
            "ROOT_MAIN_OR_EXPORTS": "NOT_PRESENT_IN_ACCEPTED_E5_PACKAGE",
            "PREP_SPECIFIC_ACCEPTED_EXPORT": "@shiwei/runtime-data-foundation/prep-academic-term-server-v1",
            "PREP_EXPORT_AGENT_REUSE": "FORBIDDEN_WITHOUT_NEW_OWNER_ACCEPTANCE",
            "AGENT_STABLE_EXPORT": "MISSING",
        },
        "E5_AGENT_ADOPTION_READINESS": "PARTIAL_UPSTREAM_ACCEPTED_AGENT_ADOPTION_NOT_ESTABLISHED",
    }

    client_boundary = {
        **common_meta("CLIENT_SERVER_CONTEXT_TRUST_BOUNDARY"),
        "CLIENT_MAY_SUGGEST_CONTEXT": "YES",
        "CLIENT_MAY_DECLARE_AUTHORITY": "NO",
        "SERVER_MUST_RE_RESOLVE_AUTHORITY": "YES",
        "INPUT_MATRIX": [
            {"INPUT": "principalId", "CLASS": "FORBIDDEN_AUTHORITY_INPUT", "SERVER_RULE": "Ignore as authority; derive via E0/E1."},
            {"INPUT": "organizationId", "CLASS": "UNTRUSTED_ASSERTION_OR_SERVER_REVALIDATABLE_REFERENCE", "SERVER_RULE": "May be optional E4 selection candidate only."},
            {"INPUT": "capability", "CLASS": "FORBIDDEN_AUTHORITY_INPUT", "SERVER_RULE": "Derive exact capability from E5 grants."},
            {"INPUT": "role", "CLASS": "FORBIDDEN_AUTHORITY_INPUT", "SERVER_RULE": "No role-to-capability shortcut; use accepted E5."},
            {"INPUT": "currentRoom", "CLASS": "VIEW_HINT", "SERVER_RULE": "May guide resolver or navigation; never authorizes room access."},
            {"INPUT": "lessonId", "CLASS": "SERVER_REVALIDATABLE_REFERENCE", "SERVER_RULE": "Require PREP/Classroom owner lookup, organization binding and revision."},
            {"INPUT": "classroomId", "CLASS": "SERVER_REVALIDATABLE_REFERENCE", "SERVER_RULE": "Require Classroom owner lookup and E5 scope."},
            {"INPUT": "reviewItemId", "CLASS": "SERVER_REVALIDATABLE_REFERENCE", "SERVER_RULE": "Require Review owner lookup and E5 scope."},
            {"INPUT": "browser route", "CLASS": "SAFE_NAVIGATION_CONTEXT", "SERVER_RULE": "Use only as view/navigation hint."},
            {"INPUT": "localStorage", "CLASS": "UNTRUSTED_ASSERTION", "SERVER_RULE": "Never store authority; any reference must be revalidated."},
            {"INPUT": "sessionStorage", "CLASS": "UNTRUSTED_ASSERTION", "SERVER_RULE": "May retain a preference; rebind to current principal/org and revalidate."},
            {"INPUT": "page-local state or URL params", "CLASS": "VIEW_HINT", "SERVER_RULE": "Never promote without owner resolution."},
        ],
        "MISMATCH_POLICY": "Server authority or domain fact wins. If the mismatch affects identity, authorization, organization or selected domain object, protected reads and L3 candidate creation fail closed.",
        "SAFE_RESPONSE_TO_UNTRUSTED_HINT": [
            "explain that the hint is not yet verified",
            "offer safe navigation without claiming a domain fact",
            "ask the corresponding server/domain resolver",
            "return an explicit unavailable or conflict state",
        ],
    }

    domain_matrix = {
        **common_meta("DOMAIN_CONTEXT_DEPENDENCY_MATRIX"),
        "DOMAINS": [
            {"OWNER": "SHARED_IDENTITY_E5", "FACTS": ["Principal", "Organization", "Membership", "ActiveOrganizationContext", "AuthorizationContext", "effective capabilities"], "ACCEPTED_SOURCE": "YES_UPSTREAM", "AGENT_ADOPTION": "NO", "V0_USE": "MANDATORY_SECURITY_CORE_AFTER_ACCEPTED_ADAPTER"},
            {"OWNER": "PREP", "FACTS": ["WorkingTermSelection", "CurrentPreparation", "RegisteredWorkSummary", "TeachingAssignment"], "ACCEPTED_SOURCE": "WORKING_TERM_AND_REGISTERED_WORK_AGENT_CONTRACT_NOT_FOUND", "AGENT_ADOPTION": "NO", "V0_USE": "MISSING_OR_CANDIDATE_UNTIL_OWNER_CONTRACT"},
            {"OWNER": "PREP_WITH_CRDF", "FACTS": ["AcademicTerm"], "ACCEPTED_SOURCE": "YES; PREP-specific server release accepted", "AGENT_ADOPTION": "NO", "V0_USE": "ON_DEMAND_AFTER_AGENT_SPECIFIC_CONSUMER_CONTRACT"},
            {"OWNER": "CLASSROOM", "FACTS": ["CurrentClassroomContext", "CurrentClassroomSession"], "ACCEPTED_SOURCE": "CURRENT_HOST_VALUES_ARE_FIXTURE_ONLY", "AGENT_ADOPTION": "NO", "V0_USE": "VIEW_HINT_ONLY; DOMAIN FACT MISSING"},
            {"OWNER": "REVIEW", "FACTS": ["CurrentReviewContext", "CurrentReviewItem"], "ACCEPTED_SOURCE": "AGENT_FACING_STABLE_REFERENCE_NOT_FOUND", "AGENT_ADOPTION": "NO", "V0_USE": "VIEW_HINT_ONLY; DOMAIN FACT MISSING"},
            {"OWNER": "SCHOOL_COMMUNITY", "FACTS": ["ClassInstance", "StudentLearner", "SubjectDefinition", "shared school facts"], "ACCEPTED_SOURCE": "AGENT_FACING_CONTRACT_NOT_FOUND", "AGENT_ADOPTION": "NO", "V0_USE": "MISSING; STUDENT DATA PROHIBITED_BY_DEFAULT"},
            {"OWNER": "CRDF", "FACTS": ["persistence mechanics", "revisioned references", "candidate durability when later authorized"], "ACCEPTED_SOURCE": "FOUNDATION_ACCEPTED_UPSTREAM", "AGENT_ADOPTION": "NO", "V0_USE": "REFERENCE_REVISION_SUPPORT_ONLY; NO_AGENT_PERSISTENCE_THIS_TASK"},
            {"OWNER": "AGENT_LINE", "FACTS": ["envelope composition", "view hints", "provenance", "freshness/conflict state", "projection policy"], "ACCEPTED_SOURCE": "CONTRACT_CANDIDATE_IN_THIS_PACKAGE", "AGENT_ADOPTION": "NOT_IMPLEMENTED", "V0_USE": "MAY_COMPOSE_REFERENCES; MAY_NOT_OWN_DOMAIN_TRUTH"},
        ],
        "REFERENCE_POLICY": "Prefer stable owner reference plus minimal Agent-relevant summary. Query full objects on demand; never copy a full domain record by default.",
        "CURRENT_V0_DOMAIN_ADMISSION": {
            "DIRECTLY_ADMITTED_AS_AGENT_TRUSTED_FACT": [],
            "ADMITTABLE_AFTER_AGENT_SPECIFIC_SERVER_ADOPTION": ["AcademicTerm stable reference and revision"],
            "MUST_REMAIN_CANDIDATE": ["WorkingTermSelection"],
            "MUST_REMAIN_MISSING_OR_FIXTURE": ["CurrentPreparation", "CurrentClassroomSession", "CurrentReviewItem", "ClassInstance", "StudentLearner", "SubjectDefinition", "TeachingAssignment"],
        },
    }

    room_candidate = {
        **common_meta("CURRENT_ROOM_SEMANTIC_CANDIDATE"),
        "STATUS": "CONTRACT_CANDIDATE_NOT_IMPLEMENTED_NOT_ACCEPTED",
        "SEMANTIC_PARTS": {
            "VIEW_CONTEXT": {"MEANING": "visible product surface and browser route", "SOURCE": "client navigation", "TRUST": "CLIENT_VIEW_HINT", "MAY_DO": ["explain visible surface", "suggest safe navigation", "select a server resolver"]},
            "DOMAIN_CONTEXT": {"MEANING": "owner-resolved current Preparation, Classroom session or Review item", "SOURCE": "accepted domain owner", "TRUST": "TRUSTED_ONLY_AFTER_SERVER_RESOLUTION_AND_REVISION_CHECK", "CURRENT_AGENT_STATE": "MOSTLY_MISSING_OR_FIXTURE"},
            "AUTHORITY_CONTEXT": {"MEANING": "E5 scope and capability for the active organization", "SOURCE": "trusted E0-E5 server chain", "TRUST": "SERVER_ONLY", "CURRENT_AGENT_STATE": "NOT_ADOPTED"},
        },
        "NON_IMPLICATIONS": [
            "URL /classroom does not imply authorized Classroom context.",
            "Opening PREP does not imply a canonical Preparation exists.",
            "A visible lesson id does not establish an owner-resolved lesson.",
            "Room visibility does not grant a capability.",
        ],
        "COMPOSITION_RULE": "CurrentRoom may contain only a view hint plus independently resolved optional domain reference and independently issued authority handle. No layer upgrades another.",
    }

    work_object = {
        **common_meta("CURRENT_WORK_OBJECT_REFERENCE_CANDIDATE"),
        "STATUS": "CONTRACT_CANDIDATE_NOT_IMPLEMENTED_NOT_ACCEPTED",
        "UNIVERSAL_CANONICAL_ENTITY": "FORBIDDEN",
        "MINIMAL_REFERENCE_FIELDS": ["domainNamespace", "objectType", "stableReference", "sourceOwner", "revisionOrVersion", "viewRelationship"],
        "OPTIONAL_FIELDS": ["minimalAgentRelevantSummary", "resolvedAt", "freshnessStatus", "privacyClass"],
        "FIELD_RULES": {
            "stableReference": "Opaque owner-defined identifier; client input remains untrusted until owner resolution.",
            "revisionOrVersion": "Required whenever owner source exposes one; conflict causes no formal action.",
            "viewRelationship": "VISIBLE, SELECTED, NAVIGATION_TARGET or NONE; never implies CURRENT_DOMAIN_FACT.",
            "minimalAgentRelevantSummary": "Only when reference alone cannot support the user task; never a full object copy by default.",
        },
        "RESOLUTION_RESULT_STATES": ["RESOLVED_CURRENT", "STALE", "CONFLICTING", "NOT_FOUND", "UNAVAILABLE_FOR_TRUSTED_AGENT_CONTEXT"],
        "CURRENT_OWNER_RESULTS": {
            "PREP": "UNAVAILABLE_EXCEPT_UPSTREAM_ACADEMIC_TERM_REFERENCE_AFTER_FUTURE_AGENT_CONTRACT",
            "CLASSROOM": "UNAVAILABLE_FOR_TRUSTED_AGENT_CONTEXT",
            "REVIEW": "UNAVAILABLE_FOR_TRUSTED_AGENT_CONTEXT",
            "SCHOOL_COMMUNITY": "UNAVAILABLE_FOR_TRUSTED_AGENT_CONTEXT",
        },
    }

    provenance = {
        **common_meta("CONTEXT_PROVENANCE_MODEL_CANDIDATE"),
        "STATUS": "CONTRACT_CANDIDATE_NOT_IMPLEMENTED_NOT_ACCEPTED",
        "MINIMUM_FIELDS": [
            "valueOrReference",
            "contextItemType",
            "sourceOwner",
            "sourceAuthority",
            "sourceReference",
            "resolutionMethod",
            "resolvedAt",
            "revisionOrVersion",
            "trustClass",
            "freshnessStatus",
            "useScope",
            "privacyClass",
        ],
        "FIELD_SEMANTICS": {
            "valueOrReference": "Prefer an opaque stable reference; inline value only if minimal and necessary.",
            "sourceAuthority": "Accepted server security authority, accepted domain owner, client hint, fixture, legacy or unknown.",
            "sourceReference": "Auditable contract/version/resolver identity; never a raw secret.",
            "resolutionMethod": "SERVER_RESOLVED, OWNER_LOOKUP, SERVER_REVALIDATED_CLIENT_REFERENCE, CLIENT_HINT, FIXTURE or UNKNOWN.",
            "freshnessStatus": "CURRENT, STALE_READABLE, STALE_FAIL_CLOSED, CONFLICTING or UNKNOWN.",
            "useScope": "ROUTING, AUTHORIZATION, TASK_READ, NAVIGATION, L3_CANDIDATE or EXPLANATION_ONLY.",
        },
        "SECURITY_HANDLE_EXCEPTION": "AuthorizationContext provenance is established by the live E5-issued in-process handle and validation call; descriptive metadata cannot recreate that authority.",
        "FORBIDDEN_BLOB_EXAMPLE": "A natural-language value such as currentContext without source, revision, trust and use scope is never trusted for formal effect.",
        "AUDITABILITY_RULE": "Every trusted or hinted item has its own provenance record; provenance is not inherited from the envelope container.",
    }

    freshness = {
        **common_meta("FRESHNESS_STALENESS_AND_CONFLICT_POLICY"),
        "POLICY_STATUS": "CONTRACT_READY_NOT_IMPLEMENTED",
        "ITEM_POLICIES": [
            {"ITEM": "VerifiedExternalAuthenticationProof", "LIFETIME": "REQUEST_OR_ACCEPTED_TRUSTED_SESSION_BOUNDARY", "CACHE": "NO_RAW_TOKEN_OR_PROOF_CACHE", "REFRESH": "REVERIFY_AT_REQUEST_BOUNDARY", "STALE_BEHAVIOR": "FAIL_CLOSED"},
            {"ITEM": "Principal", "LIFETIME": "REQUEST_REFERENCE", "CACHE": "OPAQUE_ID_MAY_BE_CORRELATED; AUTHORITY_MAY_NOT_BE_CACHED", "REFRESH": "RESOLVE_OR_VALIDATE_BINDING_PER_REQUEST", "STALE_BEHAVIOR": "FAIL_CLOSED_FOR_PROTECTED_USE"},
            {"ITEM": "ActiveOrganizationContext", "LIFETIME": "REQUEST", "CACHE": "NO_ACROSS_PROCESS_BFF_OR_SESSION", "REFRESH": "RE_RESOLVE_ON_EACH_TRUST_BOUNDARY", "STALE_BEHAVIOR": "FAIL_CLOSED"},
            {"ITEM": "AuthorizationContext", "LIFETIME": "REQUEST_IN_PROCESS", "CACHE": "FORBIDDEN", "REFRESH": "REISSUE_AND_VALIDATE_PER_REQUEST", "STALE_BEHAVIOR": "FAIL_CLOSED"},
            {"ITEM": "AcademicTerm", "LIFETIME": "REQUEST_REFERENCE", "CACHE": "REFERENCE_AND_MINIMAL_SUMMARY_ONLY_WITH_REVISION", "REFRESH": "OWNER_LOOKUP_ON_REVISION_MISMATCH_OR_TASK_NEED", "STALE_BEHAVIOR": "STALE_READABLE_ONLY_FOR_LABELED_EXPLANATION; NO_CANDIDATE_OR_EFFECT"},
            {"ITEM": "WorkingTermSelection", "LIFETIME": "BROWSER_SESSION_PREFERENCE", "CACHE": "SESSIONSTORAGE_CANDIDATE_ONLY", "REFRESH": "REBIND_TO_PRINCIPAL_ORG_AND_REVALIDATE_TERM", "STALE_BEHAVIOR": "UNKNOWN_OR_CANDIDATE; DO_NOT_INVENT"},
            {"ITEM": "Domain work object reference", "LIFETIME": "REQUEST", "CACHE": "ONLY_IF_OWNER_REVISION_AND_POLICY_ALLOW", "REFRESH": "OWNER_REVALIDATION_BEFORE L3 OR L4+", "STALE_BEHAVIOR": "NO_FORMAL_ACTION"},
            {"ITEM": "CurrentRoom/route/view hint", "LIFETIME": "PAGE_OR_NAVIGATION", "CACHE": "CLIENT_ONLY", "REFRESH": "ON_NAVIGATION", "STALE_BEHAVIOR": "SAFE_EXPLANATION_ONLY; NEVER_AUTHORITY"},
        ],
        "CONFLICT_PRECEDENCE": {
            "CLIENT_HINT_VS_SERVER_FACT": "SERVER_FACT_WINS",
            "SECURITY_AUTHORITY_CONFLICT": "NO_PROTECTED_READ_NO_CANDIDATE_NO_FORMAL_ACTION",
            "TWO_DOMAIN_SOURCES": "DO_NOT_SELECT_SILENTLY; RETURN_CONFLICT_AND_REQUEST_OWNER_RESOLUTION",
            "FIXTURE_VS_REAL_SOURCE": "REAL_ACCEPTED_OWNER_SOURCE_WINS_AND_FIXTURE_IS_EXCLUDED",
            "LEGACY_VS_CURRENT_ACCEPTED": "CURRENT_ACCEPTED_SOURCE_WINS; LEGACY_REMAINS_ARCHAEOLOGY_ONLY",
        },
    }

    def fail_row(category: str, understand: str, read: str, navigate: str, candidate: str, effect: str, response: str) -> dict[str, str]:
        return {
            "CATEGORY": category,
            "CAN_AGENT_UNDERSTAND": understand,
            "CAN_AGENT_READ": read,
            "CAN_AGENT_NAVIGATE": navigate,
            "CAN_AGENT_CREATE_CANDIDATE": candidate,
            "CAN_AGENT_EXECUTE_FORMAL_EFFECT": effect,
            "REQUIRED_RESPONSE": response,
        }

    fail_closed = {
        **common_meta("FAIL_CLOSED_MATRIX"),
        "MAX_ACTION_MATURITY": "L3",
        "L4_PLUS_IMPLEMENTATION": "NOT_AUTHORIZED",
        "ROWS": [
            fail_row("IDENTITY_UNRESOLVED", "GENERIC_NONPERSONAL_ONLY", "NO_PROTECTED_READ", "SAFE_PUBLIC_NAVIGATION_ONLY", "NO", "NO", "Return identity unavailable; do not infer from browser data."),
            fail_row("ACTIVE_ORGANIZATION_UNRESOLVED", "GENERIC_NONPERSONAL_ONLY", "NO_ORG_SCOPED_READ", "SAFE_PUBLIC_NAVIGATION_ONLY", "NO", "NO", "Require E4 resolution; do not choose an organization silently."),
            fail_row("AUTHORIZATION_CONTEXT_UNRESOLVED", "GENERIC_NONPERSONAL_ONLY", "NO_PROTECTED_READ", "SAFE_PUBLIC_NAVIGATION_ONLY", "NO", "NO", "Require live E5 context; default deny."),
            fail_row("DOMAIN_OBJECT_NOT_FOUND", "YES_WITH_EXPLICIT_NOT_FOUND", "NO_OBJECT_CONTENT", "MAY_NAVIGATE_TO_OWNER_SEARCH", "NO_OBJECT_BOUND_CANDIDATE", "NO", "Do not invent; expose not-found state."),
            fail_row("DOMAIN_OBJECT_STALE", "LABELED_STALE_EXPLANATION_ONLY", "ONLY_IF_OWNER_POLICY_ALLOWS_STALE_READ", "YES_TO_REFRESH_OR_OWNER", "NO", "NO", "Refresh by owner; retain stale marker."),
            fail_row("CLIENT_SERVER_CONTEXT_MISMATCH", "YES_WITH_CONFLICT_LABEL", "SERVER_FACT_ONLY_IF_AUTHORIZED", "YES_TO_SERVER_FACT_OR_RESOLUTION", "NO_UNTIL_RESOLVED", "NO", "Server fact wins; record mismatch."),
            fail_row("REVISION_CONFLICT", "YES_WITH_CONFLICT_LABEL", "READ_ONLY_IF_OWNER_ALLOWS", "YES_TO_RESOLUTION", "NO", "NO", "No silent last-write-wins; ask owner to resolve."),
            fail_row("FIXTURE_REALITY_CONFLICT", "YES_IF_FIXTURE_LABELED", "REAL_SOURCE_ONLY", "YES_WITHOUT_FIXTURE_AUTHORITY", "NO_FROM_FIXTURE", "NO", "Exclude fixture from trusted envelope."),
            fail_row("LEGACY_CURRENT_CONFLICT", "YES_FOR_ARCHAEOLOGY", "CURRENT_ACCEPTED_ONLY", "YES_TO_CURRENT_SURFACE", "NO_FROM_LEGACY", "NO", "Legacy is read-only archaeology and cannot establish current fact."),
            fail_row("MULTIPLE_AUTHORITY_SOURCES", "YES_WITH_AMBIGUITY", "NO_PROTECTED_READ_UNTIL_ONE_AUTHORITY", "SAFE_RESOLUTION_NAVIGATION_ONLY", "NO", "NO", "Fail closed and obtain owner/authority resolution."),
        ],
        "MANDATORY_CORE_ABSENT_MAXIMUM": [
            "generic non-personal L0 boundary explanation",
            "safe public navigation suggestion",
            "explicit unavailable/conflict reporting",
        ],
    }

    minimization = {
        **common_meta("CONTEXT_DATA_MINIMIZATION_RULES"),
        "DEFAULT": "DENY_OR_EXCLUDE_UNLESS_MINIMUM_NECESSARY_FOR_CURRENT_TASK",
        "CATEGORIES": {
            "REQUIRED_FOR_ROUTING": ["current route/surface hint", "domain namespace", "object type"],
            "REQUIRED_FOR_AUTHORIZATION": ["live E5 AuthorizationContext handle", "opaque Principal/org/membership references within trusted server only"],
            "REQUIRED_FOR_USER_TASK": ["owner-resolved stable work-object reference", "minimal summary explicitly needed by the task"],
            "OPTIONAL": ["client selected object hint", "current room hint", "on-demand domain summary"],
            "PROHIBITED_BY_DEFAULT": ["full student profile", "full teacher profile", "full school record", "full chat history", "unrelated class data", "unrelated review content", "raw token", "grant payload", "full AuthorizationContext serialization"],
        },
        "STUDENT_LEARNER_RULE": "No student record enters the default envelope or prompt. Future tasks may request only an authorized, purpose-bound minimum reference or anonymized aggregate from the owner; full private payload remains prohibited.",
        "TEACHER_RULE": "Use opaque Principal and task-required professional-work references, not a profile dump.",
        "SCHOOL_RULE": "Use active Organization reference and only task-required school facts; never include the complete organization record by default.",
        "RETENTION_RULE": "Request-scoped by default. View hints expire on navigation. Security contexts are never serialized or retained across trust boundaries.",
        "LOGGING_RULE": "Audit identifiers and state transitions only; redact tokens, credentials, private free text and full personal payloads.",
    }

    projection = {
        **common_meta("PROMPT_PROJECTION_BOUNDARY"),
        "TRUSTED_AGENT_CONTEXT_ENVELOPE": "STRUCTURED_SYSTEM_CONTEXT",
        "LLM_PROMPT_PROJECTION": "TASK_SPECIFIC_MINIMAL_VIEW_OF_TRUSTED_CONTEXT",
        "SEPARATION_RULE": "The envelope is never serialized wholesale into a model prompt.",
        "NEVER_SEND_TO_LLM": [
            "raw JWT/session token/external authentication proof",
            "live AuthorizationContext handle or serialized copy",
            "capability grant records, grant revisions and policy internals",
            "membership internals and stable IDs unless an exceptional task strictly requires a redacted reference",
            "request/session secrets",
            "full student, teacher or school profiles",
            "unrelated domain objects or chat history",
        ],
        "ROUTING_ONLY": ["domain namespace", "resolver selection", "current surface hint"],
        "AUTHORIZATION_ONLY": ["Principal/org/membership authority chain", "AuthorizationContext", "effective capabilities", "grant and policy revisions"],
        "MAY_PROJECT_IF_TASK_REQUIRES": ["human-readable active organization label after minimization", "owner-approved minimal domain summary", "current view label", "explicit freshness/conflict warning"],
        "PROJECTION_PRECONDITIONS": [
            "task purpose established",
            "source trust and freshness checked",
            "minimum necessary fields selected",
            "private fields redacted",
            "projection cannot be mistaken for authorization",
        ],
        "MODEL_OUTPUT_RULE": "Model output remains candidate-only and never upgrades a hint, stale item or missing fact into authority.",
    }

    v0_matrix = {
        **common_meta("V0_CONTEXT_REQUIREMENT_MATRIX"),
        "IMPLEMENTATION": "NOT_AUTHORIZED",
        "CANDIDATES": [
            {
                "CANDIDATE": "EXPLAIN_CURRENT_CONTEXT_BOUNDARY",
                "LEVEL": "L0",
                "MINIMUM_CONTEXT": ["current route or room view hint", "availability/trust labels"],
                "TRUSTED_CONTEXT_REQUIRED": "NO_FOR_GENERIC_EXPLANATION; YES_FOR_PERSONALIZED_FACT_CLAIMS",
                "CLIENT_HINT_ALLOWED": "YES_AS_LABELED_HINT",
                "E5_REQUIRED": "NO_FOR_GENERIC_EXPLANATION",
                "DOMAIN_OWNER_REQUIRED": "NO_UNLESS_EXPLAINING_A_SPECIFIC_DOMAIN_FACT",
                "LLM_REQUIRED": "NO",
                "PROMPT_CONTEXT_REQUIRED": "NO",
                "FAIL_CLOSED_TRIGGER": "Any request to claim protected identity/domain fact without trusted core",
                "CURRENT_DEPENDENCY_GAP": "None for generic boundary explanation; personalized claims blocked",
            },
            {
                "CANDIDATE": "GET_CURRENT_WORKING_TERM",
                "LEVEL": "L1",
                "MINIMUM_CONTEXT": ["Principal", "ActiveOrganizationContext", "live AuthorizationContext", "PREP WorkingTermSelection"],
                "TRUSTED_CONTEXT_REQUIRED": "YES",
                "CLIENT_HINT_ALLOWED": "Optional term/org selection candidate only",
                "E5_REQUIRED": "YES; accepted academic-term:discover exists upstream",
                "DOMAIN_OWNER_REQUIRED": "YES_PREP",
                "LLM_REQUIRED": "NO",
                "PROMPT_CONTEXT_REQUIRED": "NO",
                "FAIL_CLOSED_TRIGGER": "Identity/org/auth unresolved, term absent/stale, or preference binding mismatch",
                "CURRENT_DEPENDENCY_GAP": "Agent E0-E5 adoption and accepted PREP WorkingTerm Agent contract missing",
            },
            {
                "CANDIDATE": "GET_CURRENT_REGISTERED_WORK_SUMMARY",
                "LEVEL": "L1_TO_L2_READ",
                "MINIMUM_CONTEXT": ["trusted security core", "active organization", "WorkingTerm", "owner-resolved registered-work reference and revision"],
                "TRUSTED_CONTEXT_REQUIRED": "YES",
                "CLIENT_HINT_ALLOWED": "Optional selected work reference candidate",
                "E5_REQUIRED": "YES_EXACT_READ_CAPABILITY_NOT_YET_DEFINED_FOR_AGENT",
                "DOMAIN_OWNER_REQUIRED": "YES_PREP_AND_POSSIBLY_SCHOOL_COMMUNITY",
                "LLM_REQUIRED": "NO",
                "PROMPT_CONTEXT_REQUIRED": "NO",
                "FAIL_CLOSED_TRIGGER": "Missing capability, owner contract, revision or organization binding",
                "CURRENT_DEPENDENCY_GAP": "Accepted registered-work summary contract and Agent capability/grant missing",
            },
            {
                "CANDIDATE": "NAVIGATE_TO_CURRENT_REGISTERED_WORK",
                "LEVEL": "L2",
                "MINIMUM_CONTEXT": ["current route hint", "owner-resolved registered-work reference", "safe destination contract"],
                "TRUSTED_CONTEXT_REQUIRED": "YES_FOR_TARGET_REFERENCE; NO_AUTHORITY_FROM_ROUTE",
                "CLIENT_HINT_ALLOWED": "YES",
                "E5_REQUIRED": "YES_IF_TARGET_OR_RESOLUTION_IS_PROTECTED",
                "DOMAIN_OWNER_REQUIRED": "YES_PREP",
                "LLM_REQUIRED": "NO",
                "PROMPT_CONTEXT_REQUIRED": "NO",
                "FAIL_CLOSED_TRIGGER": "Target not found/stale, cross-org mismatch, or route-only target",
                "CURRENT_DEPENDENCY_GAP": "Accepted registered-work target/reference contract missing",
            },
            {
                "CANDIDATE": "CREATE_NEXT_STEP_CANDIDATE",
                "LEVEL": "L3",
                "MINIMUM_CONTEXT": ["trusted security core", "fresh owner-resolved current work reference", "registered work summary", "candidate destination and provenance"],
                "TRUSTED_CONTEXT_REQUIRED": "YES",
                "CLIENT_HINT_ALLOWED": "YES_AS_VIEW_RELATIONSHIP_ONLY",
                "E5_REQUIRED": "YES_EXACT_CAPABILITY_REQUIRED",
                "DOMAIN_OWNER_REQUIRED": "YES_FOR_SOURCE_AND_CANDIDATE_SEMANTICS",
                "LLM_REQUIRED": "OPTIONAL_NOT_REQUIRED_BY_CONTEXT_CONTRACT",
                "PROMPT_CONTEXT_REQUIRED": "ONLY_MINIMAL_TASK_SPECIFIC_PROJECTION_IF_MODEL_USED",
                "FAIL_CLOSED_TRIGGER": "Any missing/stale/conflicting security or domain prerequisite",
                "CURRENT_DEPENDENCY_GAP": "Agent E5 adoption, owner candidate contract, persistence boundary and exact capability missing",
            },
        ],
        "NO_LLM_REQUIRED_COUNT": 4,
        "OPTIONAL_LLM_COUNT": 1,
    }

    envelope = {
        **common_meta("TRUSTED_CONTEXT_ENVELOPE_V0_CANDIDATE"),
        "STATUS": "CONTRACT_CANDIDATE_NOT_IMPLEMENTED_NOT_FORMALLY_ACCEPTED",
        "DESIGN_GOAL": "Small request-scoped composition of independent trusted references and labeled hints; not a second database or universal context graph.",
        "MANDATORY_TRUSTED_CORE": [
            {"FIELD": "envelopeIdentity", "RULE": "unique non-secret request envelope identity"},
            {"FIELD": "requestSessionCorrelation", "RULE": "request-scoped audit correlation; never identity authority"},
            {"FIELD": "principalReference", "RULE": "E1-resolved stable opaque reference plus revision/provenance"},
            {"FIELD": "activeOrganizationReference", "RULE": "E4-resolved organization and membership references plus revisions and resolution method"},
            {"FIELD": "authorizationHandle", "RULE": "opaque live E5-issued in-process handle/reference; never serialized"},
            {"FIELD": "itemProvenance", "RULE": "per-item source, resolution, trust, freshness, use and privacy metadata"},
            {"FIELD": "conflictState", "RULE": "explicit unresolved/stale/conflicting flags"},
            {"FIELD": "projectionPolicy", "RULE": "task-specific allowlist and redaction boundary"},
        ],
        "OPTIONAL_TRUSTED_DOMAIN_CONTEXT": [
            "AcademicTerm reference after Agent-specific accepted owner/server contract",
            "WorkingTerm reference after PREP owner acceptance",
            "domain current-work reference after owner resolution",
            "minimal task-specific owner summary",
        ],
        "OPTIONAL_CLIENT_VIEW_HINT": ["current route", "visible product surface", "selected object candidate", "navigation target"],
        "ON_DEMAND_CONTEXT": ["full domain lookup", "authorized learner aggregate", "review detail", "candidate destination"],
        "REFERENCE_COPY_POLICY": {
            "REFERENCE_SUFFICIENT": ["Principal", "Organization", "Membership", "AcademicTerm", "current work object"],
            "SUMMARY_REQUIRED": "Only if the current task cannot be performed from a reference and the owner supplies an approved minimal view.",
            "FULL_OBJECT_REQUIRED": [],
            "QUERY_ON_DEMAND": ["domain content", "classroom details", "review details", "learner information"],
            "UNKNOWN": "Remain unknown; never infer.",
        },
        "MANDATORY_CORE_MISSING_BEHAVIOR": {
            "ALLOWED": ["generic non-personal L0 explanation", "safe public navigation", "explicit unavailable/conflict response"],
            "FORBIDDEN": ["protected reads", "personalized domain claims", "real-work-bound L3 candidates", "formal effects"],
        },
        "AUTHORIZATION_HANDLE_RULE": "Capability checks occur through the E5 boundary. Effective capability/grant payloads are not copied into the envelope or prompt.",
        "NON_GOALS": ["runtime schema", "context broker", "workflow engine", "universal context graph", "Agent-owned school model", "prompt builder"],
    }

    requirements = [
        {"REQUIREMENT_ID": "XLR-FG002-01", "TARGET_OWNER_LINE": "SHARED_IDENTITY_E5", "REQUIRED_FACT_OR_CONTRACT": "Accepted Agent-specific trusted-server consumer channel/export for E0-E5 issue and validate operations", "CURRENT_EVIDENCE": "E5 accepted at b6bd78d; private package has no root main/exports; only accepted public consumer export found is PREP-specific", "CURRENT_STATUS": "MISSING", "WHY_AGENT_NEEDS_IT": "Produce the mandatory trusted security core without relative/private imports or copied semantics", "REQUIRED_FOR_L0": "PERSONALIZED_ONLY", "REQUIRED_FOR_L1": "YES", "REQUIRED_FOR_L2": "YES", "REQUIRED_FOR_L3": "YES", "REQUIRED_FOR_L4_PLUS": "YES", "BLOCKING_LEVEL": "BLOCKS_FIRST_FG002_IMPLEMENTATION_SLICE", "REQUESTED_OWNER_RESPONSE": "Accept a minimal Agent server consumer contract and stable import surface that preserves live in-process E5 provenance."},
        {"REQUIREMENT_ID": "XLR-FG002-02", "TARGET_OWNER_LINE": "SHARED_IDENTITY_E0_AND_FORMAL_AGENT_HOST_INTEGRATION_OWNER", "REQUIRED_FACT_OR_CONTRACT": "Accepted Agent request/session ingress mapped to E0 verified proof and E1 Principal resolution", "CURRENT_EVIDENCE": "Host has static loopback PREP BFF and unused platform-header helper, but no accepted Agent auth ingress", "CURRENT_STATUS": "MISSING", "WHY_AGENT_NEEDS_IT": "No Principal or E4/E5 context can be trusted without a server authentication entrypoint", "REQUIRED_FOR_L0": "PERSONALIZED_ONLY", "REQUIRED_FOR_L1": "YES", "REQUIRED_FOR_L2": "YES", "REQUIRED_FOR_L3": "YES", "REQUIRED_FOR_L4_PLUS": "YES", "BLOCKING_LEVEL": "BLOCKS_FIRST_FG002_IMPLEMENTATION_SLICE", "REQUESTED_OWNER_RESPONSE": "Bind the formal host request boundary to accepted E0 without exposing tokens or accepting browser IDs."},
        {"REQUIREMENT_ID": "XLR-FG002-03", "TARGET_OWNER_LINE": "SHARED_IDENTITY_E5_AND_DOMAIN_OWNERS", "REQUIRED_FACT_OR_CONTRACT": "Exact Agent read/candidate capabilities and persisted grants", "CURRENT_EVIDENCE": "Accepted V1 catalog exposes academic-term:discover only; no Agent capability/grant adoption", "CURRENT_STATUS": "MISSING_FOR_AGENT_OPERATIONS", "WHY_AGENT_NEEDS_IT": "Authorize L1-L3 protected reads and candidate creation with exact capabilities", "REQUIRED_FOR_L0": "NO", "REQUIRED_FOR_L1": "PER_OPERATION", "REQUIRED_FOR_L2": "YES", "REQUIRED_FOR_L3": "YES", "REQUIRED_FOR_L4_PLUS": "YES", "BLOCKING_LEVEL": "NON_BLOCKING_FOR_CORE_CONTRACT_BUT_BLOCKS_PROTECTED_CAPABILITIES", "REQUESTED_OWNER_RESPONSE": "Define only task-proven exact capabilities after domain contracts exist; no role shortcut."},
        {"REQUIREMENT_ID": "XLR-FG002-04", "TARGET_OWNER_LINE": "PREP", "REQUIRED_FACT_OR_CONTRACT": "Accepted Agent-facing WorkingTerm, current Preparation and registered-work summary/reference contracts", "CURRENT_EVIDENCE": "AcademicTerm release is accepted for PREP; PREP adoption is candidate only; remaining work objects are fixtures or absent", "CURRENT_STATUS": "PARTIAL_CANDIDATE", "WHY_AGENT_NEEDS_IT": "Support four of five V0 candidates without Agent redefining PREP semantics", "REQUIRED_FOR_L0": "NO", "REQUIRED_FOR_L1": "YES_FOR_TERM_AND_SUMMARY", "REQUIRED_FOR_L2": "YES", "REQUIRED_FOR_L3": "YES", "REQUIRED_FOR_L4_PLUS": "YES", "BLOCKING_LEVEL": "NON_BLOCKING_FOR_SECURITY_CORE; BLOCKS_DOMAIN_CANDIDATES", "REQUESTED_OWNER_RESPONSE": "Publish stable references, revision/freshness semantics and minimum summaries for Agent consumption."},
        {"REQUIREMENT_ID": "XLR-FG002-05", "TARGET_OWNER_LINE": "SCHOOL_COMMUNITY", "REQUIRED_FACT_OR_CONTRACT": "Accepted minimal shared facts for ClassInstance, SubjectDefinition, TeachingAssignment and privacy-safe learner references", "CURRENT_EVIDENCE": "Current host values are fixtures; no accepted Agent-facing contract found", "CURRENT_STATUS": "MISSING", "WHY_AGENT_NEEDS_IT": "Resolve cross-room school facts without creating an Agent-owned school model", "REQUIRED_FOR_L0": "NO", "REQUIRED_FOR_L1": "NO_FOR_GENERIC_TERM", "REQUIRED_FOR_L2": "POSSIBLE", "REQUIRED_FOR_L3": "POSSIBLE", "REQUIRED_FOR_L4_PLUS": "YES_WHEN_EFFECT_TOUCHES_FACT", "BLOCKING_LEVEL": "NON_BLOCKING_FOR_FIRST_SECURITY_CORE", "REQUESTED_OWNER_RESPONSE": "Define minimum stable references, revisions and privacy classes; keep learner data excluded by default."},
        {"REQUIREMENT_ID": "XLR-FG002-06", "TARGET_OWNER_LINE": "CLASSROOM", "REQUIRED_FACT_OR_CONTRACT": "Accepted current Classroom context/session reference and freshness policy", "CURRENT_EVIDENCE": "Current contracts explicitly identify fixtureOnly, non-persisted previews", "CURRENT_STATUS": "MISSING", "WHY_AGENT_NEEDS_IT": "Distinguish visible Classroom surface from a real active session", "REQUIRED_FOR_L0": "NO", "REQUIRED_FOR_L1": "NO", "REQUIRED_FOR_L2": "WHEN_NAVIGATING_CLASSROOM", "REQUIRED_FOR_L3": "WHEN_CANDIDATE_USES_CLASSROOM", "REQUIRED_FOR_L4_PLUS": "YES_FOR_CLASSROOM_EFFECT", "BLOCKING_LEVEL": "NON_BLOCKING_FOR_FIRST_SECURITY_CORE", "REQUESTED_OWNER_RESPONSE": "Provide an owner-resolved stable session/reference contract; fixtures remain non-authoritative."},
        {"REQUIREMENT_ID": "XLR-FG002-07", "TARGET_OWNER_LINE": "REVIEW", "REQUIRED_FACT_OR_CONTRACT": "Accepted current Review context/item reference and privacy-safe minimal summary", "CURRENT_EVIDENCE": "Only route/view state or fixture-like content found; no stable Agent-facing contract", "CURRENT_STATUS": "MISSING", "WHY_AGENT_NEEDS_IT": "Explain/navigate Review without inventing a review item or leaking content", "REQUIRED_FOR_L0": "NO", "REQUIRED_FOR_L1": "NO", "REQUIRED_FOR_L2": "WHEN_NAVIGATING_REVIEW", "REQUIRED_FOR_L3": "WHEN_CANDIDATE_USES_REVIEW", "REQUIRED_FOR_L4_PLUS": "YES_FOR_REVIEW_EFFECT", "BLOCKING_LEVEL": "NON_BLOCKING_FOR_FIRST_SECURITY_CORE", "REQUESTED_OWNER_RESPONSE": "Publish stable references, revisions, visibility and minimum projection rules."},
        {"REQUIREMENT_ID": "XLR-FG002-08", "TARGET_OWNER_LINE": "CRDF", "REQUIRED_FACT_OR_CONTRACT": "Agent candidate persistence and revision/conflict boundary when a later L3 task is authorized", "CURRENT_EVIDENCE": "CRDF mechanics exist upstream but no Agent persistence contract or implementation is authorized", "CURRENT_STATUS": "NOT_REQUESTED_YET", "WHY_AGENT_NEEDS_IT": "Persist future L3 candidates without making the envelope a database", "REQUIRED_FOR_L0": "NO", "REQUIRED_FOR_L1": "NO", "REQUIRED_FOR_L2": "NO", "REQUIRED_FOR_L3": "YES_IF_DURABLE", "REQUIRED_FOR_L4_PLUS": "YES", "BLOCKING_LEVEL": "NON_BLOCKING_FOR_FIRST_SECURITY_CORE", "REQUESTED_OWNER_RESPONSE": "Wait for a bounded candidate-persistence task; define revision and conflict semantics without domain ownership transfer."},
    ]
    xlr = {
        **common_meta("CROSS_LINE_REQUIREMENT_REGISTER"),
        "CROSS_LINE_REQUIREMENT_COUNT": len(requirements),
        "CROSS_LINE_BLOCKING_REQUIREMENT_COUNT": 2,
        "NON_BLOCKING_REQUIREMENT_COUNT": 6,
        "REQUIREMENTS": requirements,
        "NO_SELF_DEFINITION_RULE": "Agent line records missing owner contracts and waits; it does not fill them with new canonical objects or authorization semantics.",
    }

    fg = {
        **common_meta("FG_002_COMPONENT_READINESS"),
        "COMPONENTS": [
            {"COMPONENT": "FG_002A_SECURITY_AND_AUTHORITY_CONTEXT_CORE", "STATUS": "PARTIAL", "CLOSED_NOW": "Minimum contract and accepted E0-E5 reuse semantics are defined", "OPEN_GAP": "Agent consumer channel and request ingress are missing", "IMPLEMENTATION_READY": "NO"},
            {"COMPONENT": "FG_002B_DOMAIN_CONTEXT_REFERENCE_FRAMEWORK", "STATUS": "PARTIAL", "CLOSED_NOW": "Owner/reference/revision framework and current classifications are defined", "OPEN_GAP": "Only AcademicTerm is accepted upstream; Agent-specific term adoption and other domain contracts are missing", "IMPLEMENTATION_READY": "NO_FOR_DOMAIN_CONTEXT"},
            {"COMPONENT": "FG_002C_CLIENT_VIEW_HINT_BOUNDARY", "STATUS": "READY", "CLOSED_NOW": "Client suggestion, forbidden authority inputs and server revalidation rules are explicit", "OPEN_GAP": "Runtime enforcement not implemented by this task", "IMPLEMENTATION_READY": "CONTRACT_READY"},
            {"COMPONENT": "FG_002D_PROVENANCE_FRESHNESS_AND_FAIL_CLOSED_POLICY", "STATUS": "READY", "CLOSED_NOW": "Per-item provenance, lifetime, revisions, conflicts and ten fail-closed categories are defined", "OPEN_GAP": "Runtime enforcement not implemented by this task", "IMPLEMENTATION_READY": "CONTRACT_READY"},
            {"COMPONENT": "FG_002E_PROMPT_PROJECTION_AND_DATA_MINIMIZATION_BOUNDARY", "STATUS": "READY", "CLOSED_NOW": "Envelope/prompt separation, projection allowlist and default data exclusions are defined", "OPEN_GAP": "Prompt builder is intentionally out of scope", "IMPLEMENTATION_READY": "CONTRACT_READY"},
        ],
        "OVERALL": "PARTIAL",
        "RATIONALE": "The design contract closes, but the mandatory security core cannot yet be produced by the formal Agent host from accepted interfaces.",
    }

    implementation = {
        **common_meta("IMPLEMENTATION_SLICE_CANDIDATE"),
        "TRUSTED_AGENT_CONTEXT_ENVELOPE_READINESS": "PARTIAL",
        "RECOMMENDED_IMPLEMENTATION_SLICE": "NONE_CONTRACT_ONLY",
        "NEXT_IMPLEMENTATION_TASK_ELIGIBLE": "NO",
        "WHY_NO_SLICE": [
            "No accepted Agent-specific E0-E5 trusted-server consumer channel/export exists.",
            "No accepted Agent request/session ingress maps the formal host to E0/E1.",
            "The PREP-specific accepted export cannot be generalized by the Agent line.",
        ],
        "EARLIEST_POSSIBLE_FUTURE_SLICE_AFTER_BLOCKERS": "Server-only request-scoped Principal plus ActiveOrganizationContext plus live AuthorizationContext handle plus per-item provenance; no domain mutation, no model, no action registry.",
        "FUTURE_SLICE_CONSTRAINTS": ["small", "server-first", "fail-closed", "no formal domain mutation", "no model dependency", "no action registry", "reuse accepted E5", "testable"],
        "NOT_AUTHORIZED": ["Agent branch", "Agent worktree", "context resolver", "E5 adapter", "API route", "context broker", "tool router", "action registry", "model router", "L4+ action"],
    }

    answers = [
        {"QUESTION_ID": 1, "ANSWER": "A trusted Principal source exists only in accepted upstream E0-to-E1 server code: E0 verifies the Clerk proof and E1 resolves an opaque stable Principal. The current Agent host request path does not call it, so Agent currently has no trusted Principal."},
        {"QUESTION_ID": 2, "ANSWER": "E4 determines Active Organization server-side from current Principal and Memberships. Client organizationId is only an optional selection candidate; multiple memberships require explicit choice plus server revalidation."},
        {"QUESTION_ID": 3, "ANSWER": "No. AgentDock and the host have no accepted Agent auth ingress, E4 resolution, E5 issue/validate call or Agent consumer export. A copied JSON context would not satisfy E5 provenance."},
        {"QUESTION_ID": 4, "ANSWER": "Agent may reuse accepted E0-E5 identity/organization/membership/resolution/authorization semantics and exact validation APIs after an Agent-specific server consumer contract. AcademicTerm semantics are accepted upstream, but the released public export is PREP-specific and not Agent authority."},
        {"QUESTION_ID": 5, "ANSWER": "PREP must provide WorkingTerm, Preparation and registered-work facts; Classroom must provide session/context; Review must provide item/context; School Community must provide shared class/subject/assignment/learner facts; CRDF supplies persistence mechanics; E5 supplies security authority."},
        {"QUESTION_ID": 6, "ANSWER": "Current Room, PREP and Review context are route/view hints; selected object and AgentDock are page-local state; Preparation lesson, Classroom context/session, Review item, class, learner, subject and teaching assignment are current fixtures."},
        {"QUESTION_ID": 7, "ANSWER": "Browser may suggest organization, room, route, selected object and domain reference candidates, and may request safe navigation. Each remains labeled and server-revalidated where it touches a protected/domain fact."},
        {"QUESTION_ID": 8, "ANSWER": "Browser may never declare Principal, effective Organization, Membership, role-derived authority, capability, grant, AuthorizationContext or domain ownership/revision truth."},
        {"QUESTION_ID": 9, "ANSWER": "The minimum trusted core is envelope/request identity, E1 Principal reference, E4 active Organization plus Membership references and revisions, a live opaque E5 AuthorizationContext handle, and per-item provenance/freshness/conflict/privacy metadata."},
        {"QUESTION_ID": 10, "ANSWER": "No domain item can enter current Agent V0 as REAL_ACCEPTED_SOURCE today. AcademicTerm is the first admissible stable reference after an Agent-specific accepted server contract; route/room can enter only as client hints."},
        {"QUESTION_ID": 11, "ANSWER": "WorkingTerm remains DOMAIN_CANDIDATE. Preparation, Classroom session, Review item, ClassInstance, learner, SubjectDefinition and TeachingAssignment remain FIXTURE or MISSING until their owners publish accepted contracts."},
        {"QUESTION_ID": 12, "ANSWER": "View is the visible surface/route, Domain is an owner-resolved current object, and Authority is E5 scope/capability. They coexist as independently sourced fields; none implies another."},
        {"QUESTION_ID": 13, "ANSWER": "Yes as a non-canonical lightweight framework: domain namespace, object type, stable owner reference, source owner, revision and view relationship. It is unavailable when no owner-stable object exists."},
        {"QUESTION_ID": 14, "ANSWER": "Each item carries value/reference, type, source owner/authority/reference, resolution method/time, revision, trust, freshness, use scope and privacy class. E5 authority additionally requires the live issued handle."},
        {"QUESTION_ID": 15, "ANSWER": "E0 proof, Principal binding, Organization, Membership, E4 and E5 require per-boundary/current-revision checks; domain references require owner revisions; WorkingTerm preferences require principal/org rebinding; view hints refresh on navigation."},
        {"QUESTION_ID": 16, "ANSWER": "Identity, active organization or authorization unresolved; stale security; authority ambiguity; revision conflict; client/server mismatch affecting protected scope; and stale/not-found domain prerequisites all block protected reads, L3 candidates as applicable, and every formal effect."},
        {"QUESTION_ID": 17, "ANSWER": "The envelope is structured system context. Prompt projection is a separate task-specific, minimized and redacted view. The full envelope is never serialized to a model."},
        {"QUESTION_ID": 18, "ANSWER": "Raw auth proof/token, live AuthorizationContext, capability grants/policies/revisions, membership internals, routing-only references, request secrets and unrelated personal/domain data never need to be sent to an LLM."},
        {"QUESTION_ID": 19, "ANSWER": "Default-deny projection, explicit task-purpose allowlists, opaque references, on-demand owner queries, student-data prohibition by default, privacy classes and no wholesale envelope serialization prevent profile/data dumps."},
        {"QUESTION_ID": 20, "ANSWER": "The V0 matrix closes each candidate: L0 generic explanation needs hints only; term and registered-work reads need trusted core plus PREP facts; navigation needs a server-resolved target; L3 candidate needs fresh core, owner reference and exact capability. None requires an LLM by contract."},
        {"QUESTION_ID": 21, "ANSWER": "FG-002A PARTIAL; FG-002B PARTIAL; FG-002C READY; FG-002D READY; FG-002E READY."},
        {"QUESTION_ID": 22, "ANSWER": "Two requirements block the first implementation slice: an accepted Agent-specific E0-E5 server consumer channel/export, and an accepted formal-host request/session ingress mapped to E0/E1."},
        {"QUESTION_ID": 23, "ANSWER": "No implementation slice is currently eligible. A smallest future slice is identifiable, but its mandatory trusted security inputs lack accepted Agent integration surfaces."},
        {"QUESTION_ID": 24, "ANSWER": "No. This task does not authorize a branch/worktree, and readiness is PARTIAL rather than READY_FOR_BOUNDED_IMPLEMENTATION_TASK."},
        {"QUESTION_ID": 25, "ANSWER": "Yes. Remain at pure Contract stage until the two blocking security-integration requirements are accepted; starting now would require private imports, PREP contract generalization or invented authority."},
    ]
    readiness = {
        **common_meta("READINESS"),
        "EXECUTION_RESULT": "PASS_READONLY_CONTRACT_AND_DEPENDENCY_CLOSURE",
        "TRUSTED_AGENT_CONTEXT_ENVELOPE_READINESS": "PARTIAL",
        "SECURITY_AUTHORITY_CONTEXT_READINESS": "PARTIAL_UPSTREAM_ACCEPTED_AGENT_CONSUMER_CHANNEL_MISSING",
        "DOMAIN_CONTEXT_REFERENCE_READINESS": "PARTIAL",
        "CLIENT_VIEW_HINT_BOUNDARY_READINESS": "READY",
        "PROVENANCE_READINESS": "READY",
        "FRESHNESS_AND_FAIL_CLOSED_READINESS": "READY",
        "DATA_MINIMIZATION_READINESS": "READY",
        "PROMPT_PROJECTION_BOUNDARY_READINESS": "READY",
        "E5_AGENT_ADOPTION_READINESS": "PARTIAL_UPSTREAM_ACCEPTED_AGENT_ADOPTION_NOT_ESTABLISHED",
        "CONTEXT_ITEM_COUNT": 24,
        "REAL_ACCEPTED_SOURCE_COUNT": 0,
        "REAL_ACCEPTED_BUT_NOT_AGENT_ADOPTED_COUNT": 8,
        "CLIENT_VIEW_HINT_COUNT": 4,
        "FIXTURE_COUNT": 8,
        "MISSING_OR_UNKNOWN_COUNT": 1,
        "CROSS_LINE_REQUIREMENT_COUNT": 8,
        "CROSS_LINE_BLOCKING_REQUIREMENT_COUNT": 2,
        "NON_BLOCKING_REQUIREMENT_COUNT": 6,
        "FG_002A_STATUS": "PARTIAL",
        "FG_002B_STATUS": "PARTIAL",
        "FG_002C_STATUS": "READY",
        "FG_002D_STATUS": "READY",
        "FG_002E_STATUS": "READY",
        "RECOMMENDED_IMPLEMENTATION_SLICE": "NONE_CONTRACT_ONLY",
        "NEXT_IMPLEMENTATION_TASK_ELIGIBLE": "NO",
        "SOURCE_CODE_CHANGE_COUNT": 0,
        "GIT_MUTATION_COUNT": 0,
        "NEW_BRANCH_COUNT": 0,
        "NEW_WORKTREE_COUNT": 0,
        "AGENT_IMPLEMENTATION_CHANGE_COUNT": 0,
        "FORMAL_RUNTIME_SCHEMA_IMPLEMENTATION": "NO",
        "MANDATORY_QUESTION_ANSWERS": answers,
        "STOP_POINT": STOP_POINT,
    }

    evidence = {
        **common_meta("AUDIT_EVIDENCE_INDEX"),
        "EVIDENCE_CLASSES": ["TASK_AUTHORITY", "PARENT_ACCEPTANCE", "WORKING_START_FACT", "CURRENT_HEAD_FACT", "UPSTREAM_ACCEPTED_CONTRACT_FACT", "CANDIDATE_FACT"],
        "SOURCES": [
            {"CLASS": "TASK_AUTHORITY", "PATH": TASK_SOURCE, "BYTES": 37113, "SHA256": "D5850CAD1AC9CB3C393F0E3A49A8F02143987709E1CEDC100791EA18CDB8A8B3", "FULL_READ": "PASS"},
            {"CLASS": "PARENT_ACCEPTANCE", "PATH": PARENT_ZIP, "BYTES": 46629, "SHA256": "DD1C4EC5AEB30CE8AF9D1E69782CAC73B0FBBB1D44181AE713F62948B483C36C", "FULL_READ": "PASS"},
            {"CLASS": "WORKING_START_FACT", "PATH": HOST_REPO, "REF": "refs/tags/classroom-semester-workset-m2-accepted-20260718", "COMMIT": "c875cde9ab63bca2b9c06ec17832393a67d0e617", "TREE": "a1ba3d4d715539987db8cd8b03ce1020eddddd74"},
            {"CLASS": "CURRENT_HEAD_FACT", "PATH": HOST_REPO, "COMMIT": "4f853665a4e23f03a68f9df72d77e8131a197b84", "TREE": "8d6d7f36c416dd7cceebbba146e458111b6542b1", "STATUS": "CLEAN_AT_AUDIT_NOT_ACCEPTED_BASELINE"},
            {"CLASS": "UPSTREAM_ACCEPTED_CONTRACT_FACT", "PATH": E5_BINDING, "BYTES": 6583, "SHA256": "65A09ACB0192B0C348EB763AE3BE801BF874AD3C48D2C8E9069FEA1A3B0159B6", "RESULT": "PASS_AND_CLOSE_E5"},
            {"CLASS": "UPSTREAM_ACCEPTED_CONTRACT_FACT", "PATH": PREP_RELEASE_BINDING, "BYTES": 6477, "SHA256": "3E85A45A360FCDB2FB6981DF1D89565F5837E275D8D2183CDB9041C40796F9C0", "RESULT": "PASS_AND_CLOSE_RELEASE_01_PREP_SPECIFIC"},
            {"CLASS": "CANDIDATE_FACT", "PATH": PREP_ADOPTION, "COMMIT": "ecd182a2d57f3d6e6133421308dafa2c920093c0", "STATUS": "CANDIDATE_COMPLETE_FOR_GPT_REVIEW_NOT_FORMALLY_ACCEPTED"},
            {"CLASS": "GOVERNANCE_SOURCE", "PATH": GOV_REPO + r"\development-history\philosophy\shiwei-core-product-philosophy\README.md", "ACTIVE_VERSION": "v1.0", "FULL_READ": "PASS"},
            {"CLASS": "GOVERNANCE_SOURCE", "PATH": GOV_REPO + r"\development-history\philosophy\shiwei-open-capability-boundary-principle\README.md", "FULL_READ": "PASS"},
            {"CLASS": "GOVERNANCE_SOURCE", "PATH": GOV_REPO + r"\development-history\philosophy\shiwei-xiaojiao-registered-work-and-controlled-action-principle\README.md", "FULL_READ": "PASS"},
        ],
        "SECRET_OR_PII_EXPOSURE_RISK": "NO_RAW_SECRET_OR_FULL_PRIVATE_PAYLOAD_COPIED_TO_PACKAGE",
        "READ_LIMIT": "Evidence contains structural findings and exact identities only; no JWT, credentials, passwords or private student/teacher content.",
    }

    validation = {
        **common_meta("PACKAGE_VALIDATION"),
        "VALIDATOR": "build_agent02_review.py --verify-existing",
        "EXPECTED_FILE_COUNT": 26,
        "GATES": {
            "UNIQUE_PACKAGE": "PASS_IF_BUILDER_COMPLETES_WITH_TARGET_PREEXISTENCE_GUARD",
            "STRICT_JSON_AND_DUPLICATE_KEYS": "PASS_IF_BUILDER_COMPLETES",
            "UTF8_NO_BOM": "PASS_IF_BUILDER_COMPLETES",
            "LF": "PASS_IF_BUILDER_COMPLETES",
            "PATH_SAFETY": "PASS_IF_BUILDER_COMPLETES",
            "MANIFEST_COVERAGE": "PASS_IF_BUILDER_COMPLETES",
            "SHA256SUMS_COVERAGE": "PASS_IF_BUILDER_COMPLETES",
            "PACKAGE_FULL_READ": "PASS_IF_BUILDER_COMPLETES",
            "FIXED_TIMESTAMP": "PASS_IF_BUILDER_COMPLETES",
            "DEFLATE": "PASS_IF_BUILDER_COMPLETES",
            "DETERMINISTIC_REBUILD": "PASS_IF_BUILDER_COMPLETES",
        },
        "ZIP_IDENTITY": "COMPUTED_AFTER_PACKAGE_BUILD_AND_REPORTED_EXTERNALLY_TO_AVOID_SELF_REFERENCE",
    }

    review_reference = {
        **common_meta("REVIEW_PACKAGE_REFERENCE"),
        "PACKAGE_NAME": f"{PACKAGE_BASENAME}.zip",
        "WRAPPER_DIRECTORY": PACKAGE_BASENAME,
        "PACKAGE_PATH": str(ZIP_PATH),
        "PACKAGE_IDENTITY": "FINAL_SHA256_AND_BYTES_COMPUTED_AFTER_DETERMINISTIC_BUILD",
        "REVIEW_TARGET": "SHIWEI_XIAOJIAO_AGENT_ORCHESTRATION_LINE",
        "REVIEW_TYPE": "CUMULATIVE_REVIEW",
        "AUTOMATIC_ADVANCE": "NO",
        "NEXT_TASK_AUTHORIZED": "NO",
        "STOP_POINT": STOP_POINT,
    }

    artifacts = {
        "XIAOJIAO_AGENT_02_PARENT_AUTHORITY_AND_BASELINE_RECOVERY.json": parent,
        "XIAOJIAO_AGENT_02_CONTEXT_ITEM_INVENTORY.json": inventory_artifact,
        "XIAOJIAO_AGENT_02_CONTEXT_SOURCE_AND_AUTHORITY_MAP.json": source_map,
        "XIAOJIAO_AGENT_02_SECURITY_IDENTITY_E5_DEPENDENCY_AUDIT.json": security,
        "XIAOJIAO_AGENT_02_CLIENT_SERVER_CONTEXT_TRUST_BOUNDARY.json": client_boundary,
        "XIAOJIAO_AGENT_02_DOMAIN_CONTEXT_DEPENDENCY_MATRIX.json": domain_matrix,
        "XIAOJIAO_AGENT_02_CURRENT_ROOM_SEMANTIC_CANDIDATE.json": room_candidate,
        "XIAOJIAO_AGENT_02_CURRENT_WORK_OBJECT_REFERENCE_CANDIDATE.json": work_object,
        "XIAOJIAO_AGENT_02_CONTEXT_PROVENANCE_MODEL_CANDIDATE.json": provenance,
        "XIAOJIAO_AGENT_02_FRESHNESS_STALENESS_AND_CONFLICT_POLICY.json": freshness,
        "XIAOJIAO_AGENT_02_FAIL_CLOSED_MATRIX.json": fail_closed,
        "XIAOJIAO_AGENT_02_CONTEXT_DATA_MINIMIZATION_RULES.json": minimization,
        "XIAOJIAO_AGENT_02_PROMPT_PROJECTION_BOUNDARY.json": projection,
        "XIAOJIAO_AGENT_02_V0_CONTEXT_REQUIREMENT_MATRIX.json": v0_matrix,
        "XIAOJIAO_AGENT_02_TRUSTED_CONTEXT_ENVELOPE_V0_CANDIDATE.json": envelope,
        "XIAOJIAO_AGENT_02_CROSS_LINE_REQUIREMENT_REGISTER.json": xlr,
        "XIAOJIAO_AGENT_02_FG_002_COMPONENT_READINESS.json": fg,
        "XIAOJIAO_AGENT_02_IMPLEMENTATION_SLICE_CANDIDATE.json": implementation,
        "XIAOJIAO_AGENT_02_READINESS.json": readiness,
        "AUDIT_EVIDENCE_INDEX.json": evidence,
        "XIAOJIAO_AGENT_02_PACKAGE_VALIDATION.json": validation,
        "REVIEW_PACKAGE_REFERENCE.json": review_reference,
    }
    for name, payload in artifacts.items():
        write_json(name, payload)

    readme = textwrap.dedent(
        f"""
        # XIAOJIAO_AGENT_02 GPT 累计审核说明

        TASK_ID = {TASK_ID}

        EXECUTION_RESULT = PASS_READONLY_CONTRACT_AND_DEPENDENCY_CLOSURE

        TRUSTED_AGENT_CONTEXT_ENVELOPE_READINESS = PARTIAL

        本包只闭合 FG-002 的可信上下文合同、Authority 来源、Client/Server 边界、Provenance、Freshness、Fail-Closed、数据最小化、Prompt Projection 与跨线依赖。未实现 Runtime Schema、Agent Server、E5 Adapter、API、Tool、Action、Model Router 或 L4+ 动作。

        ## 核心裁决

        - 上游 E0-E5 已正式接受，但当前 Agent host 尚无可信请求入口、Agent 专用 consumer channel 或 E5 E2E adoption。
        - 当前 24 个 Context Item 中，0 个已经是 Agent 可用的 REAL_ACCEPTED_SOURCE；8 个是上游已接受但 Agent 未接入；4 个是 Client View Hint；8 个是 Fixture；1 个缺失/未知；其余为 1 个 Domain Candidate 与 2 个 Page-local state。
        - Browser 可建议 Context，但不能声明 Principal、Organization Authority、Membership、Capability、Role Authority 或 AuthorizationContext。
        - Current Room 必须拆成 View、Domain 与 Authority；Current Working Object 只能是 owner-resolved 轻量引用，不能成为万能实体。
        - Envelope 是结构化系统上下文；Prompt Projection 是任务专用、最小化、脱敏视图。完整 Envelope 永不整体发送给模型。
        - FG-002A = PARTIAL；FG-002B = PARTIAL；FG-002C/D/E = READY。
        - 两条真正阻塞首个实现 Slice 的 Requirement：Agent 专用 E0-E5 trusted-server consumer channel，以及 formal host 到 E0/E1 的可信 request/session ingress。
        - RECOMMENDED_IMPLEMENTATION_SLICE = NONE_CONTRACT_ONLY；NEXT_IMPLEMENTATION_TASK_ELIGIBLE = NO。

        ## 审核路径

        1. 先读 XIAOJIAO_AGENT_02_READINESS.json，查看总体结论与 25 个正式问题。
        2. 再读 XIAOJIAO_AGENT_02_PARENT_AUTHORITY_AND_BASELINE_RECOVERY.json，核对父任务、host 与 Working Start。
        3. 读 XIAOJIAO_AGENT_02_CONTEXT_ITEM_INVENTORY.json 与 SOURCE_AND_AUTHORITY_MAP，核对逐项分类。
        4. 读 SECURITY_IDENTITY_E5_DEPENDENCY_AUDIT 与 CLIENT_SERVER_CONTEXT_TRUST_BOUNDARY，核对 E0-E5 与 browser 边界。
        5. 读 DOMAIN_CONTEXT_DEPENDENCY_MATRIX、CURRENT_ROOM 与 CURRENT_WORK_OBJECT，核对 Domain Owner Lock。
        6. 读 PROVENANCE、FRESHNESS、FAIL_CLOSED、DATA_MINIMIZATION、PROMPT_PROJECTION 与 V0 matrix。
        7. 最后读 CROSS_LINE_REQUIREMENT_REGISTER、FG_002_COMPONENT_READINESS 与 IMPLEMENTATION_SLICE_CANDIDATE。

        ## 证据与包验证

        AUDIT_EVIDENCE_INDEX.json 记录 exact source class、commit/tree、binding hash 与候选/accepted 边界。MANIFEST.json 覆盖除 MANIFEST.json、SHA256SUMS.txt 之外的全部 entry；SHA256SUMS.txt 覆盖除自身之外的全部 entry。build_agent02_review.py 可执行独立 --verify-existing，复核 strict JSON duplicate keys、UTF-8 no BOM、LF、path safety、coverage、full read、fixed timestamp、deflate 与 deterministic rebuild。

        SOURCE_CODE_CHANGE_COUNT = 0

        GIT_MUTATION_COUNT = 0

        NEW_BRANCH_COUNT = 0

        NEW_WORKTREE_COUNT = 0

        AGENT_IMPLEMENTATION_CHANGE_COUNT = 0

        STOP_POINT = {STOP_POINT}
        """
    ).lstrip()
    write_text("README_FOR_GPT_REVIEW.md", readme)


def parse_json_strict(path: Path) -> object:
    raw = path.read_bytes()
    if raw.startswith(b"\xef\xbb\xbf"):
        raise AssertionError(f"BOM found: {path.name}")
    if b"\r" in raw:
        raise AssertionError(f"CR found: {path.name}")
    text_value = raw.decode("utf-8")
    return json.loads(text_value, object_pairs_hook=strict_pairs)


def validate_folder() -> dict[str, object]:
    files = sorted(path for path in ROOT.iterdir() if path.is_file())
    names = [path.name for path in files]
    required = {
        "XIAOJIAO_AGENT_02_PARENT_AUTHORITY_AND_BASELINE_RECOVERY.json",
        "XIAOJIAO_AGENT_02_CONTEXT_ITEM_INVENTORY.json",
        "XIAOJIAO_AGENT_02_CONTEXT_SOURCE_AND_AUTHORITY_MAP.json",
        "XIAOJIAO_AGENT_02_SECURITY_IDENTITY_E5_DEPENDENCY_AUDIT.json",
        "XIAOJIAO_AGENT_02_CLIENT_SERVER_CONTEXT_TRUST_BOUNDARY.json",
        "XIAOJIAO_AGENT_02_DOMAIN_CONTEXT_DEPENDENCY_MATRIX.json",
        "XIAOJIAO_AGENT_02_CURRENT_ROOM_SEMANTIC_CANDIDATE.json",
        "XIAOJIAO_AGENT_02_CURRENT_WORK_OBJECT_REFERENCE_CANDIDATE.json",
        "XIAOJIAO_AGENT_02_CONTEXT_PROVENANCE_MODEL_CANDIDATE.json",
        "XIAOJIAO_AGENT_02_FRESHNESS_STALENESS_AND_CONFLICT_POLICY.json",
        "XIAOJIAO_AGENT_02_FAIL_CLOSED_MATRIX.json",
        "XIAOJIAO_AGENT_02_CONTEXT_DATA_MINIMIZATION_RULES.json",
        "XIAOJIAO_AGENT_02_PROMPT_PROJECTION_BOUNDARY.json",
        "XIAOJIAO_AGENT_02_V0_CONTEXT_REQUIREMENT_MATRIX.json",
        "XIAOJIAO_AGENT_02_TRUSTED_CONTEXT_ENVELOPE_V0_CANDIDATE.json",
        "XIAOJIAO_AGENT_02_CROSS_LINE_REQUIREMENT_REGISTER.json",
        "XIAOJIAO_AGENT_02_FG_002_COMPONENT_READINESS.json",
        "XIAOJIAO_AGENT_02_IMPLEMENTATION_SLICE_CANDIDATE.json",
        "XIAOJIAO_AGENT_02_READINESS.json",
        "README_FOR_GPT_REVIEW.md",
        "REVIEW_PACKAGE_REFERENCE.json",
        "MANIFEST.json",
        "SHA256SUMS.txt",
    }
    missing = sorted(required - set(names))
    if missing:
        raise AssertionError(f"required artifacts missing: {missing}")
    if len(files) != 26:
        raise AssertionError(f"expected 26 wrapper files, got {len(files)}: {names}")

    for path in files:
        raw = path.read_bytes()
        if raw.startswith(b"\xef\xbb\xbf"):
            raise AssertionError(f"BOM found: {path.name}")
        if b"\r" in raw:
            raise AssertionError(f"CR found: {path.name}")
        raw.decode("utf-8")
        if path.suffix == ".json":
            parse_json_strict(path)

    manifest = parse_json_strict(ROOT / "MANIFEST.json")
    assert isinstance(manifest, dict)
    manifest_entries = manifest["ENTRIES"]
    assert isinstance(manifest_entries, list)
    expected_manifest_names = sorted(set(names) - {"MANIFEST.json", "SHA256SUMS.txt"})
    actual_manifest_names = sorted(str(entry["PATH"]) for entry in manifest_entries)
    if actual_manifest_names != expected_manifest_names:
        raise AssertionError("manifest coverage mismatch")
    for entry in manifest_entries:
        path = ROOT / str(entry["PATH"])
        raw = path.read_bytes()
        if entry["BYTES"] != len(raw) or entry["SHA256"] != sha256_bytes(raw):
            raise AssertionError(f"manifest identity mismatch: {path.name}")

    sums_lines = (ROOT / "SHA256SUMS.txt").read_text(encoding="utf-8").splitlines()
    parsed_sums: dict[str, str] = {}
    for line in sums_lines:
        digest, name = line.split("  ", 1)
        if name in parsed_sums:
            raise AssertionError(f"duplicate sums path: {name}")
        parsed_sums[name] = digest
    expected_sum_names = sorted(set(names) - {"SHA256SUMS.txt"})
    if sorted(parsed_sums) != expected_sum_names:
        raise AssertionError("SHA256SUMS coverage mismatch")
    for name, digest in parsed_sums.items():
        if digest != sha256_bytes((ROOT / name).read_bytes()):
            raise AssertionError(f"SHA256SUMS mismatch: {name}")

    readiness = parse_json_strict(ROOT / "XIAOJIAO_AGENT_02_READINESS.json")
    inventory = parse_json_strict(ROOT / "XIAOJIAO_AGENT_02_CONTEXT_ITEM_INVENTORY.json")
    requirements = parse_json_strict(ROOT / "XIAOJIAO_AGENT_02_CROSS_LINE_REQUIREMENT_REGISTER.json")
    assert isinstance(readiness, dict) and isinstance(inventory, dict) and isinstance(requirements, dict)
    if len(readiness["MANDATORY_QUESTION_ANSWERS"]) != 25:
        raise AssertionError("mandatory question answer count is not 25")
    if len(inventory["ITEMS"]) != 24:
        raise AssertionError("context item count is not 24")
    if len(requirements["REQUIREMENTS"]) != 8:
        raise AssertionError("requirement count is not 8")

    return {
        "WRAPPER_FILE_COUNT": len(files),
        "JSON_FILE_COUNT": sum(1 for path in files if path.suffix == ".json"),
        "MANIFEST_ENTRY_COUNT": len(manifest_entries),
        "SHA256SUMS_ENTRY_COUNT": len(parsed_sums),
        "STRICT_JSON_AND_DUPLICATE_KEYS": "PASS",
        "UTF8_NO_BOM": "PASS",
        "LF": "PASS",
        "MANIFEST_COVERAGE": "PASS",
        "SHA256SUMS_COVERAGE": "PASS",
    }


def build_zip_bytes() -> bytes:
    buffer = io.BytesIO()
    prefix = ROOT.name
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted((p for p in ROOT.iterdir() if p.is_file()), key=lambda p: p.name):
            arcname = f"{prefix}/{path.name}"
            info = zipfile.ZipInfo(arcname, FIXED_ZIP_TIMESTAMP)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    return buffer.getvalue()


def validate_zip(zip_bytes: bytes) -> dict[str, object]:
    rebuilt = build_zip_bytes()
    if rebuilt != zip_bytes:
        raise AssertionError("deterministic rebuild mismatch")
    prefix = ROOT.name + "/"
    expected_files = sorted(path.name for path in ROOT.iterdir() if path.is_file())
    with zipfile.ZipFile(io.BytesIO(zip_bytes), "r") as archive:
        infos = archive.infolist()
        names = [info.filename for info in infos]
        expected_names = [prefix + name for name in expected_files]
        if names != expected_names:
            raise AssertionError("ZIP entry coverage or order mismatch")
        for info in infos:
            pure = PurePosixPath(info.filename)
            if pure.is_absolute() or ".." in pure.parts or not info.filename.startswith(prefix):
                raise AssertionError(f"unsafe ZIP path: {info.filename}")
            if info.date_time != FIXED_ZIP_TIMESTAMP:
                raise AssertionError(f"non-fixed timestamp: {info.filename}")
            if info.compress_type != zipfile.ZIP_DEFLATED:
                raise AssertionError(f"non-deflate entry: {info.filename}")
            payload = archive.read(info.filename)
            local = ROOT / pure.name
            if payload != local.read_bytes():
                raise AssertionError(f"ZIP content mismatch: {info.filename}")
        bad = archive.testzip()
        if bad is not None:
            raise AssertionError(f"ZIP full read failed at: {bad}")
    return {
        "PATH_SAFETY": "PASS",
        "PACKAGE_FULL_READ": "PASS",
        "FIXED_TIMESTAMP": "PASS",
        "DEFLATE": "PASS",
        "DETERMINISTIC_REBUILD": "PASS",
        "ZIP_ENTRY_COUNT": len(expected_files),
        "ZIP_BYTES": len(zip_bytes),
        "ZIP_SHA256": sha256_bytes(zip_bytes),
    }


def create_manifest_and_sums() -> None:
    payload_files = sorted(
        path for path in ROOT.iterdir()
        if path.is_file() and path.name not in {"MANIFEST.json", "SHA256SUMS.txt"}
    )
    manifest = {
        **common_meta("MANIFEST"),
        "WRAPPER_DIRECTORY": ROOT.name,
        "COVERAGE_RULE": "All package files except MANIFEST.json and SHA256SUMS.txt; those are explicit self-reference exceptions.",
        "ENTRY_COUNT": len(payload_files),
        "ENTRIES": [
            {"PATH": path.name, "BYTES": len(path.read_bytes()), "SHA256": sha256_bytes(path.read_bytes())}
            for path in payload_files
        ],
    }
    write_json("MANIFEST.json", manifest)
    sum_files = sorted(path for path in ROOT.iterdir() if path.is_file() and path.name != "SHA256SUMS.txt")
    lines = [f"{sha256_bytes(path.read_bytes())}  {path.name}" for path in sum_files]
    write_text("SHA256SUMS.txt", "\n".join(lines) + "\n")


def build() -> dict[str, object]:
    existing = sorted(path.name for path in ROOT.iterdir() if path.is_file())
    if ZIP_PATH.exists():
        raise AssertionError(f"unique package target already exists: {ZIP_PATH}")
    if existing != [Path(__file__).name] and len(existing) != 26:
        raise AssertionError(
            "wrapper must contain only builder or the exact 26-file fail-closed resume set "
            f"before first ZIP write, found: {existing}"
        )
    build_artifacts()
    create_manifest_and_sums()
    folder_result = validate_folder()
    first = build_zip_bytes()
    second = build_zip_bytes()
    if first != second:
        raise AssertionError("deterministic rebuild failed before write")
    zip_result = validate_zip(first)
    with ZIP_PATH.open("xb") as stream:
        stream.write(first)
    on_disk = ZIP_PATH.read_bytes()
    if on_disk != first:
        raise AssertionError("on-disk ZIP differs from built bytes")
    return {
        "TASK_ID": TASK_ID,
        "EXECUTION_RESULT": "PASS_READONLY_CONTRACT_AND_DEPENDENCY_CLOSURE",
        **folder_result,
        **zip_result,
        "REVIEW_PACKAGE": str(ZIP_PATH),
        "UNIQUE_PACKAGE": "PASS",
        "STOP_POINT": STOP_POINT,
    }


def verify_existing() -> dict[str, object]:
    if not ZIP_PATH.is_file():
        raise AssertionError(f"ZIP not found: {ZIP_PATH}")
    folder_result = validate_folder()
    zip_bytes = ZIP_PATH.read_bytes()
    zip_result = validate_zip(zip_bytes)
    return {
        "TASK_ID": TASK_ID,
        "INDEPENDENT_EXISTING_PACKAGE_VERIFICATION": "PASS",
        **folder_result,
        **zip_result,
        "REVIEW_PACKAGE": str(ZIP_PATH),
        "UNIQUE_PACKAGE": "PASS_SINGLE_EXACT_TARGET",
        "STOP_POINT": STOP_POINT,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--verify-existing", action="store_true")
    args = parser.parse_args()
    result = verify_existing() if args.verify_existing else build()
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
