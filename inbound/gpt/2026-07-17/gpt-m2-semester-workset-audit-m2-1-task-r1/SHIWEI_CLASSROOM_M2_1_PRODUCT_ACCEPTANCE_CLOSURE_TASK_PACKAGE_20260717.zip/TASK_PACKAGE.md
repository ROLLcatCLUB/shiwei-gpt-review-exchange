# CLASSROOM_M2_1_PRODUCT_SEMANTICS_RESEARCH_REFERENCE_STATE_HIERARCHICAL_ARCHIVE_AND_TEACHER_DENSITY_CLOSURE

## 任务定位

在现有 M2 feature branch/worktree 中修正 M2 审核发现的产品语义和状态闭合问题。

本轮不新增新的大产品方向，不接真实 Runtime、数据库、模型或研究室页面。

## F1：研究引用成为真实 fixture 状态

将：

```text
researchCandidateConfirmed: boolean
```

升级为真实状态：

```text
researchHandoffCandidates: ResearchHandoffCandidate[]
activeResearchCandidateId
researchCandidateEditorState
```

要求：

- 每次候选具有唯一 ID；
- 确认后保存返回对象；
- 所选课堂包更新 `researchReferenceIds`；
- 归档 guard 能识别新候选；
- 支持查看、编辑草稿、撤销候选；
- 不复制课堂事实；
- 刷新后仍按 fixture 规则重置。

加强 `createResearchHandoffCandidate()`：

- objectName 非空；
- evidenceRef 必须属于所选课堂包；
- sessionPackageId 唯一；
- 非匿名化必须出现额外教师确认说明。

## F2：研究入口改为按需抽屉/确认面

默认课堂记录页不再永久显示完整研究表单。

入口来自：

- 单班课堂包；
- 跨班汇总；
- 多选课堂包操作栏。

打开后进入右侧抽屉或模态确认面。关闭后不占用记录页面空间。

默认首屏只显示轻量：

```text
已有研究引用 1
建立研究引用
```

不得开发研究室真实页面。

## F3：教师界面隐藏技术身份

默认模式隐藏：

- lessonRevisionId 原始 URI；
- classroomSnapshotId；
- snapshotHash；
- evidenceRef URI；
- teacherReflectionRef URI；
- `RESEARCH ROOM HOLD` 英文工程标签。

建立折叠的：

```text
版本与来源详情
```

或 debug 模式查看技术证据。

默认使用教师语言：

```text
版本 V0.5-P1
课堂快照已锁定
证据 2 条
研究引用 1 项
```

## F4：默认折叠与信息密度

初始状态：

```text
today = true
week = false
recent = true
semester = false
recordHierarchy = false
researchDrawer = false
```

“按层级回看”默认折叠；教师打开后再显示单元树。

保持：

- 下一节课置顶；
- 今天默认展开；
- 最近完成轻量；
- 不把所有记录和研究表单纵向堆叠。

## F5：补齐工作动作语义

### 置顶 / 常用

必须真正影响工作集：

- 置顶课时进入“置顶/常用”轻量区，或在本学期课架中置前；
- 常用课时可快速再次预演/复用；
- 按钮文案与状态一致。

### 复用本课

新增 fixture-only 复用动作：

```text
选择目标班级 / 日期
→ 创建新的 ClassroomScheduleInstance 候选
→ 引用原 lessonRevision / snapshot
→ 不覆盖历史课堂包
```

### 开始课堂

下一节课主卡明确提供：

```text
课前预览
开始课堂
```

开始课堂只进入现有 M1 当前课堂 fixture，不创建真实 Session。

## F6：确定性优先级解析

建立：

```text
deriveClassroomWorksetPriority()
```

输入：

- referenceNow；
- scheduledAt；
- readiness；
- 是否已有课堂包；
- 是否完成；
- 教师置顶和常用。

输出：

```text
NEXT
TODAY
WEEK
RECENT_COMPLETE
SEMESTER_ONLY
```

fixture 可保存预期结果用于断言，但 UI 不得只依赖手工 priority。

处理空状态：

- 没有下一节课；
- 今天没有课；
- 本周无课；
- 学期全部完成；
- 空工作集。

删除 `find(...)!` 非空假设。

## F7：归档状态语义

将当前稳定状态收敛为：

```text
currentStatus = ACTIVE | ARCHIVED
lastTransition = ARCHIVED | RESTORED | null
```

或恢复后回到 `ACTIVE`，另留 transition history。

归档和恢复不得改变课堂事实、快照哈希、研究引用。

## F8：层级软归档

实现 fixture-only：

```text
归档单班课堂实例
归档子课时
归档大单元
恢复子课时
恢复大单元
```

层级归档必须计算：

- 待整理数量；
- 待教师决定数量；
- 未完成班级；
- 研究引用数量；
- 可归档实例数量。

存在 blocker 时失败关闭；允许部分归档时必须清楚说明范围，不得静默跳过。

## F9：搜索和筛选

最低范围：

### 课前准备

- 搜课题；
- 筛选今天/本周/待准备/存在提醒。

### 课堂记录

- 搜课题、班级；
- 按单元、流程状态、归档状态筛选；
- 清除筛选。

不得降低字号或把筛选常驻成复杂后台工具栏；1366 下可进入轻量抽屉。

## F10：截图证据修复

删除或替换 3 张空白图：

```text
03
11
14
```

重新提供可见视口证据：

- 跨班汇总；
- 完整课前层级；
- 学期课架展开；
- 研究抽屉；
- 技术详情折叠；
- 空工作集；
- 子课时归档；
- 大单元归档；
- 搜索筛选。

输出：

```text
INVALID_SCREENSHOT_COUNT = 0
VALID_SCREENSHOT_COUNT >= 20
```

继续保留 1366 / 1440 / 1920 DOM 几何证据。

## 工程要求

- 保持原教室入口；
- 不新增页面；
- M1 当前课堂回归；
- Student Display 安全回归；
- 不继续把全部逻辑堆进 `ClassroomSurface`；
- 研究、归档和优先级逻辑进入 domain/controller；
- 不安装第三方依赖。

## 最终门禁

```text
RESEARCH_CANDIDATE_PERSISTED_IN_FIXTURE_STATE = PASS
RESEARCH_REFERENCE_RELATION_UPDATED = PASS
RESEARCH_FORM_DEFAULT_VISIBLE = 0
TECHNICAL_ID_DEFAULT_VISIBLE = 0
SEMESTER_FRAME_DEFAULT_EXPANDED = 0
RECORD_HIERARCHY_DEFAULT_EXPANDED = 0
PIN_AND_FREQUENT_HAVE_EFFECT = PASS
REUSE_LESSON_FIXTURE = PASS
START_CLASS_FIXTURE = PASS
PRIORITY_DERIVED = PASS
NO_NEXT_LESSON_EMPTY_STATE = PASS
RESTORE_RETURNS_ACTIVE_STATE = PASS
LESSON_ARCHIVE = PASS
UNIT_ARCHIVE = PASS
SEARCH_AND_FILTER = PASS
INVALID_SCREENSHOT_COUNT = 0
M1_REGRESSION = PASS
REAL_SIDE_EFFECT = 0
```

完成后停止在 M2 稳定合并审核门。
