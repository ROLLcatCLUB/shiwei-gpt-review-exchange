# 后续建议

## 第一步：M2.1 产品与状态闭合

```text
CLASSROOM_M2_1_PRODUCT_SEMANTICS
_RESEARCH_REFERENCE_STATE
_HIERARCHICAL_ARCHIVE
_AND_TEACHER_DENSITY_CLOSURE
```

M2.1 只修 M2 已承诺但未闭合的产品语义，不进入真实 Runtime。

## 第二步：教师/GPT复核并稳定合并

M2.1 通过后：

1. Git merge 到稳定站点；
2. 稳定仓复跑全站门禁；
3. 建立 `classroom-semester-workset-m2-accepted-20260717`；
4. 删除 M2 worktree；
5. 不手工回写页面。

## 第三步：进入 M3

建议下一个大里程碑：

```text
CLASSROOM_M3_LOCAL_DESKTOP_RUNTIME_HOST
_AND_SINGLE_MACHINE_SESSION_VERTICAL_SLICE
```

M3 第一次解除的 HOLD 仅限：

```text
Electron 桌面壳
本地确定性 ClassroomSession
本地命令执行
本地事件日志
教师窗口 + 学生展示窗口
离线素材就绪检查
ClassroomActualRecord 草稿
```

继续 HOLD：

```text
云端模型
语音 Agent
学生实时连接
WebSocket
正式数据库
正式成绩和评价
研究室真实写回
家长端
```
